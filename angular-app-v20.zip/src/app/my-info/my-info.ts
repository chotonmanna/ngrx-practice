import { Component, contentChild, signal } from '@angular/core';

@Component({
  selector: 'app-my-info',
  imports: [],
  templateUrl: './my-info.html',
  styleUrl: './my-info.scss'
})
export class MyInfo {
  fname = signal('Biswajit');
}
