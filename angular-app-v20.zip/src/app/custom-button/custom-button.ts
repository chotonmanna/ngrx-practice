import { Component } from '@angular/core';

@Component({
  selector: 'button[custom-btn]',
  imports: [],
  templateUrl: './custom-button.html',
  styleUrl: './custom-button.scss'
})
export class CustomButton {

}
