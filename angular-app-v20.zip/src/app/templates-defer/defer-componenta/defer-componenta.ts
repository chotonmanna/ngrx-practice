import { Component, afterNextRender, signal } from '@angular/core';

@Component({
  selector: 'app-defer-componenta',
  imports: [],
  templateUrl: './defer-componenta.html',
  styleUrl: './defer-componenta.scss'
})
export class DeferComponentA {
  executionText = signal('');

  constructor() {

    // afterNextRender(() => {
      
    // });

    this.heavyComputation();
  }

  private heavyComputation() {
    this.executionText.set('Starting heavy computation...');
    const startTime = performance.now();
    let result = 0;
    for (let i = 0; i < 2000000000; i++) {
      result += Math.sqrt(i);
    }
    const endTime = performance.now();
    this.executionText.set(`Heavy computation finished in ${endTime - startTime} ms`);

  }

}
