import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeferComponenta } from './defer-componenta';

describe('DeferComponenta', () => {
  let component: DeferComponenta;
  let fixture: ComponentFixture<DeferComponenta>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeferComponenta]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeferComponenta);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
