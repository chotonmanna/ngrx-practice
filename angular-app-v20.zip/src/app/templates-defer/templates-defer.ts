import { Component, signal } from '@angular/core';
import { DeferComponentA } from './defer-componenta/defer-componenta.js';

@Component({
  selector: 'app-templates-defer',
  imports: [DeferComponentA],
  templateUrl: './templates-defer.html',
  styleUrl: './templates-defer.scss'
})
export class TemplatesDefer {
  isReady = signal(false);

  constructor() {
    setTimeout(() => {
      this.isReady.set(true);
    }, 5000);
  }
}
