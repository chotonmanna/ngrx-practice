import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplatesDefer } from './templates-defer';

describe('TemplatesDefer', () => {
  let component: TemplatesDefer;
  let fixture: ComponentFixture<TemplatesDefer>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TemplatesDefer]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TemplatesDefer);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
