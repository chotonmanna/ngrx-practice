import { Component, computed, input, model, output } from '@angular/core';
import { CustomButton } from 'app/custom-button/custom-button.js';

@Component({
  selector: 'app-hello-world',
  imports: [CustomButton],
  templateUrl: './hello-world.html',
  styleUrl: './hello-world.scss'
})
export class HelloWorld {
  name = input.required<string>();
  age = model.required<number>();
  displayText = computed(() => `My Name is ${this.name()}`);
  ageChanged = output();
  //displayAge = computed(() => `My na`);

  onClick() {
    this.age.update(oldVal => oldVal + 10);
    this.ageChanged.emit();
  }
}

function modifyAge(value: number) {
  return `${value} yrs`;
}
