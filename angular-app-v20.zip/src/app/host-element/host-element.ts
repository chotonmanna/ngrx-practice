import { Component, signal } from '@angular/core';
import { CustomButton } from 'app/custom-button/custom-button.js';

@Component({
  selector: 'app-host-element',
  imports: [CustomButton],
  templateUrl: './host-element.html',
  styleUrl: './host-element.scss',
  host: {
    '[class]': 'className()'
  }
})
export class HostElement {
  protected className = signal('active');

  onClickChangeClass() {
    this.className.set('inactive');
  }
}
