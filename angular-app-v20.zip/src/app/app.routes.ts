import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'templates/defer',
    loadComponent: () => import('./templates-defer/templates-defer.js').then(c => c.TemplatesDefer)
  },
  {
    path: 'templates/ng-container',
    loadComponent: () => import('./templates-ng-container/templates-ng-container.js').then(c => c.TemplatesNgContainer)
  },
  {
    path: 'directives',
    loadComponent: () => import('./directives/directives.js').then(c => c.Directives)
  },
  {
    path: 'csv-web',
    loadComponent: () => import('./csv-web/csv-web.js').then(c => c.CsvWeb)
  },
  {
    path: 'my-payroll',
    loadChildren: () => import('./my-payroll/payroll.route.js').then(r => r.payrollRoutes)
  }
];
