import { Component, input } from '@angular/core';

@Component({
  selector: 'app-personal-details',
  imports: [],
  templateUrl: './personal-details.html',
  styleUrl: './personal-details.scss'
})
export class PersonalDetails {
  selectFrom = input.required();
  constructor() {
    //this.selectFrom.l
  }
}
