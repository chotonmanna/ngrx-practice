import { Component, TemplateRef, ViewContainerRef, inject, input, viewChild } from '@angular/core';

@Component({
  selector: 'app-button-container',
  imports: [],
  templateUrl: './button-container.html',
  styleUrl: './button-container.scss'
})
export class ButtonContainer {
  private readonly containerRef = inject(ViewContainerRef);
  fragment = input<TemplateRef<unknown> | undefined>();

  onClick() {
    if (this.fragment()) {
      this.containerRef.createEmbeddedView(this.fragment() as TemplateRef<unknown>, {message: 'Hello World'});
    }
  }
}
