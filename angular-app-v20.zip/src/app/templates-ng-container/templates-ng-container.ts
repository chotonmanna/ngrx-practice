import { Component, TemplateRef, computed, signal, viewChild } from '@angular/core';
import { PersonalDetails } from './personal-details/personal-details.js';
import { WorkDetails } from './work-details/work-details.js';
import { NgComponentOutlet, NgTemplateOutlet } from '@angular/common';
import { ButtonContainer } from './button-container/button-container.js';

interface TemplateInfo {
  template: TemplateRef<any> | undefined;
  contextData: {
    fullname: string;
    address: string;
  }
}

@Component({
  selector: 'app-templates-ng-container',
  imports: [NgComponentOutlet, NgTemplateOutlet, ButtonContainer],
  templateUrl: './templates-ng-container.html',
  styleUrl: './templates-ng-container.scss'
})
export class TemplatesNgContainer {
  protected infoType = signal<'personal' | 'work' | null>(null);
  protected readonly infoTypeComponent = computed(() => {
    if (this.infoType() === 'personal') {
      return PersonalDetails
    }

    if (this.infoType() === 'work') {
      return WorkDetails
    }

    return null;
  });

  protected readonly personalTemplate = viewChild('personal', { read: TemplateRef });
  protected readonly workTemplate = viewChild('work', { read: TemplateRef });
  protected readonly infoTypeTemplate = computed<TemplateInfo | null>(() => {
    if (this.infoType() === 'personal') {
      return {
        template: this.personalTemplate(),
        contextData: { fullname: 'Biswajit Manna', address: 'Salkia Howrah' }
      };
    }

    if (this.infoType() === 'work') {
      return {
        template: this.workTemplate(),
        contextData: { fullname: 'Cognizant', address: 'Candor Newtown' }
      };
    }

    return null;
  });

  protected onClick(type: 'personal' | 'work') {
    this.infoType.set(type)
  }

}
