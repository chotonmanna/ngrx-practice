import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplatesNgContainer } from './templates-ng-container';

describe('TemplatesNgContainer', () => {
  let component: TemplatesNgContainer;
  let fixture: ComponentFixture<TemplatesNgContainer>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TemplatesNgContainer]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TemplatesNgContainer);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
