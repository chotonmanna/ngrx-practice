import { Component } from '@angular/core';

@Component({
  selector: 'app-work-details',
  imports: [],
  templateUrl: './work-details.html',
  styleUrl: './work-details.scss'
})
export class WorkDetails {

}
