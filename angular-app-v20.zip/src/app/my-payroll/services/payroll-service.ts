import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { BASE_API_URL, IReportFormValueType, ReportModel, SESSION_STORAGE } from '../payroll.config.js';
import { map, catchError, Observable, of } from 'rxjs';

export interface IYearMonth {
  year: string;
  months: string[];
}

export interface IPayrollResponse<T> {
  status: string;
  type?: string;
  data?: T
}

@Injectable({
  providedIn: 'root'
})
export class PayrollService {
  private readonly http = inject(HttpClient);
  private readonly baseApiUrl = inject(BASE_API_URL);
  private readonly sStorage = inject(SESSION_STORAGE);
  public duplicateReportData = signal<IReportFormValueType[]>([]);

  addReport(payload: IReportFormValueType): Observable<string> {
    const reportDate = new Date(payload.reportDate);
    payload = { ...payload, reportDate: `${reportDate.getFullYear()}-${reportDate.getMonth() + 1}-${reportDate.getDate()}` };

    return this.http.post<IPayrollResponse<IReportFormValueType[]>>(`${this.baseApiUrl}/payroll/add-expense-income`, payload).pipe(
      map(resp => resp?.status),
      catchError((err: HttpErrorResponse) => {
        console.log(err.error);
        if (err.error?.status === 'duplicate') {
          this.duplicateReportData.set(err.error?.data);
        }
        return of(err.error.status);
      })
    );
  }

  getListOfYearsMonths(): Observable<IYearMonth[]> {
    return this.http.get(`${this.baseApiUrl}/payroll/listof-year-month`).pipe(
      map((resp: any) => {
        if (resp?.hasOwnProperty('data')) {
          return resp?.data;
        }
      }),
      catchError(err => {
        console.log('err', err);
        return [];
      })
    );
  }

  getReport(payload: IReportFormValueType): Observable<ReportModel | null> {
    const { reportDate, reportType } = payload;
    return this.http.get<IPayrollResponse<ReportModel>>(`${this.baseApiUrl}/payroll/get-reports/${reportDate}/${reportType}`).pipe(
      map((resp) => resp?.data || null),
      catchError(err => {
        console.log('err', err);
        return of(null);
      })
    );
  }

  postAuthentication(payload: any): Observable<string> {
    payload = {...payload, password: btoa(payload.password)};
    return this.http.post<IPayrollResponse<string>>(`${this.baseApiUrl}/payroll/authentication`, payload).pipe(
      map(resp => {
        if (resp.status === 'success') {
          this.sStorage.setItem('isPayrollAuthenticated', 'Y');
        }

        return '1';
      }),
      catchError((err: HttpErrorResponse) => {
        console.log(err.error);
        return of('0');
      })
    );
  }
}
