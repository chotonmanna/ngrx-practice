import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RouterOutlet, RouterLink, Router } from '@angular/router';
import { SESSION_STORAGE } from './payroll.config.js';

@Component({
  selector: 'app-my-payroll',
  imports: [RouterOutlet, RouterLink],
  templateUrl: './my-payroll.html',
  styleUrl: './my-payroll.scss',
  providers: [
    {
      provide: SESSION_STORAGE,
      useValue: sessionStorage
    }
  ],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MyPayroll {
  private readonly sStorage = inject(SESSION_STORAGE);
  private readonly router = inject(Router);

  logout() {
    this.sStorage.removeItem('isPayrollAuthenticated');
    this.router.navigateByUrl('/');
  }
}
