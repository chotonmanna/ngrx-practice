import { InjectionToken } from "@angular/core";
import { FormControl } from "@angular/forms";

export const BASE_API_URL = new InjectionToken<string>('api.url');
export const SESSION_STORAGE = new InjectionToken<Storage>('session.storage');

export type IReportType = 'srideIncome' | 'petrolExpense';

export interface IReportFormControlType {
  reportDate: FormControl<string>;
  amount: FormControl<number | null>;
  reportType: FormControl<IReportType>;
  viaRewardPoints: FormControl<boolean>;
  viaGPay: FormControl<boolean>;
}

export interface IReportFormValueType {
  reportDate: string;
  amount?: number | null;
  reportType: IReportType;
  viaRewardPoints?: boolean;
  viaGPay?: boolean;
  isConfirmedDuplicateEntry?: '0' | '1';
}

export interface ReportModel {
  year: string;
  yearlySrideIncome: number;
  yearlyPetrolExpense: number;
  yearlyPetrolExpenseViaRP?: number;
  lastRewardPointUsed?: string;
  reports: Array<{ 
    month: string;
    monthlySrideIncome: number;
    monthlyPetrolExpense: number;
    data: IReportFormValueType[] 
  }>;
}
