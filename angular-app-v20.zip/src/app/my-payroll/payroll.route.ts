import { Routes } from '@angular/router';
import { MyPayroll } from './my-payroll.js';
import { SbiCreditCardReport } from './views/sbi-credit-card-report/sbi-credit-card-report.js';
import { SridePetrolReport } from './views/sride-petrol-report/sride-petrol-report.js';
import { payrollAuthGuard } from './payroll-auth-guard.js';

export const payrollRoutes: Routes = [
  {
    path: '',
    component: MyPayroll,
    canActivate: [payrollAuthGuard],
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'sride-petrol-report'
      },
      {
        path: 'sride-petrol-report',
        component: SridePetrolReport
      },
      {
        path: 'sbi-credit-card-report',
        component: SbiCreditCardReport
      }
    ]
  }
]