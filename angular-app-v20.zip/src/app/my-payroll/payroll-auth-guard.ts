import { inject } from '@angular/core';
import { CanActivateFn } from '@angular/router';
import { SESSION_STORAGE } from './payroll.config.js';
import { MatDialog } from '@angular/material/dialog';
import { AuthPayroll } from './views/auth-payroll/auth-payroll.js';

export const payrollAuthGuard: CanActivateFn = (route, state) => {
  const sStorage = inject(SESSION_STORAGE);
  if (sStorage.getItem('isPayrollAuthenticated') === 'Y') {
    return true;
  } else {
    const dialog = inject(MatDialog);
    dialog.open(AuthPayroll, {
      width: '500px', enterAnimationDuration: '0ms', exitAnimationDuration: '0ms',
    });
    return false;
  }
};
