import { DatePipe, CurrencyPipe, NgClass, AsyncPipe } from '@angular/common';
import { Component, computed, effect, inject, input } from '@angular/core';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTableModule } from '@angular/material/table';
import { IReportFormValueType, ReportModel } from 'app/my-payroll/payroll.config.js';
import { PayrollService } from 'app/my-payroll/services/payroll-service.js';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-report-details',
  imports: [MatExpansionModule, MatTableModule, DatePipe, CurrencyPipe, NgClass, AsyncPipe],
  templateUrl: './report-details.html',
  styleUrl: './report-details.scss'
})
export class ReportDetails {
  private readonly payrollService = inject(PayrollService);
  protected listOfReports$!: Observable<ReportModel | null>;
  protected readonly searchParams = input.required<IReportFormValueType>();
  protected readonly displayedColumns = ['reportDate', 'reportType', 'amount'];
  protected readonly searchByYearOrMonth = computed(() => {
    return this.searchParams().reportDate.includes('-') ? 'M' : 'Y';
  });

  constructor() {
    // When inputs are received as signal
    effect(() => {
      if (this.searchParams()) {
       this.listOfReports$ = this.payrollService.getReport(this.searchParams());
     }
    });
  }

  // When inputs are received as @Input() decorator
  // ngOnChanges(changes: SimpleChanges): void {
  //   if (changes['searchParams']?.currentValue) {
  //     this.listOfReports$ = this.payrollService.getReport(changes['searchParams']?.currentValue);
  //   }
  // }
}
