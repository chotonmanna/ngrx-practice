import { CurrencyPipe, DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, OnInit, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogActions, MatDialogClose, MatDialogTitle, MatDialogContent, MatDialogRef } from '@angular/material/dialog';
import { PayrollService } from 'app/my-payroll/services/payroll-service.js';

@Component({
  selector: 'app-duplicate-record-confirmation',
  imports: [MatButtonModule, MatDialogActions, MatDialogClose, MatDialogTitle, MatDialogContent, DatePipe, CurrencyPipe],
  templateUrl: './duplicate-record-confirmation.html',
  styleUrl: './duplicate-record-confirmation.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DuplicateRecordConfirmation implements OnInit {
  private readonly dialogRef = inject(MatDialogRef<DuplicateRecordConfirmation>);
  protected readonly payrollService = inject(PayrollService);

  ngOnInit(): void {
    console.log(this.payrollService.duplicateReportData());
  }

  onClickYes(confirmation: string) {
    this.dialogRef.close(confirmation);
  }
}
