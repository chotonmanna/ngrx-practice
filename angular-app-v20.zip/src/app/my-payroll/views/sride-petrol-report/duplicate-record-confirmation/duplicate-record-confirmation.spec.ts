import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DuplicateRecordConfirmation } from './duplicate-record-confirmation';

describe('DuplicateRecordConfirmation', () => {
  let component: DuplicateRecordConfirmation;
  let fixture: ComponentFixture<DuplicateRecordConfirmation>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DuplicateRecordConfirmation]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DuplicateRecordConfirmation);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
