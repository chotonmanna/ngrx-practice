import { Component } from '@angular/core';
import { ShowReport } from './show-report/show-report.js';
import { AddReport } from './add-report/add-report.js';

@Component({
  selector: 'app-sride-petrol-report',
  imports: [AddReport, ShowReport],
  templateUrl: './sride-petrol-report.html',
  styleUrl: './sride-petrol-report.scss'
})
export class SridePetrolReport {

}
