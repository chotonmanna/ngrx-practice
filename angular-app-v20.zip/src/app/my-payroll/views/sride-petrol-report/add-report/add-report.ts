import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { FormGroup, FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { IReportFormControlType, IReportFormValueType } from 'app/my-payroll/payroll.config.js';
import { PayrollService } from 'app/my-payroll/services/payroll-service.js';

@Component({
  selector: 'app-add-report',
  imports: [MatFormFieldModule, MatSelectModule, MatInputModule, MatCheckboxModule, MatButtonModule,
    MatDatepickerModule, ReactiveFormsModule, MatDialogModule],
  providers: [provideNativeDateAdapter()],
  templateUrl: './add-report.html',
  styleUrl: './add-report.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AddReport implements OnInit {
  private readonly payrollService = inject(PayrollService);
  private readonly dialog = inject(MatDialog);

  protected readonly currentDate = new Date();
  protected addReportForm!: FormGroup<IReportFormControlType>;
  protected isProcessing = signal(false);
  protected processedResponse = signal('');

  constructor() { }

  ngOnInit(): void {
    this.addReportForm = new FormGroup<IReportFormControlType>({
      reportDate: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
      amount: new FormControl(null, { nonNullable: true, validators: [Validators.required] }),
      reportType: new FormControl('srideIncome', { nonNullable: true }),
      viaRewardPoints: new FormControl({ value: false, disabled: true }, { nonNullable: true }),
      viaGPay: new FormControl({ value: false, disabled: false }, { nonNullable: true })
    });

    this.addReportForm.get('reportType')?.valueChanges.subscribe(value => {
      if (value === 'srideIncome') {
        this.addReportForm.get('viaGPay')?.enable();
        this.addReportForm.get('viaRewardPoints')?.disable();
      } else {
        this.addReportForm.get('viaGPay')?.disable();
        this.addReportForm.get('viaRewardPoints')?.enable();
      }
    })
  }

  onSubmitReport(isConfirmedDuplicateEntry: '0' | '1' = '0') {
    this.addReportForm.markAllAsTouched();
    if (this.addReportForm.valid) {
      this.isProcessing.set(true);
      let formValues = this.addReportForm.value as IReportFormValueType;
      formValues.isConfirmedDuplicateEntry = isConfirmedDuplicateEntry;
      this.payrollService.addReport(formValues).subscribe(
        (resp) => {
          this.isProcessing.set(false);
          this.processedResponse.set(resp);
          if (resp === 'success') {
            this.addReportForm.reset();
          }

          if (resp === 'duplicate') {
            this.showDuplicateRecordWarning();
          }
        }
      );
    }
  }

  private async showDuplicateRecordWarning() {
    const { DuplicateRecordConfirmation } = await import('../duplicate-record-confirmation/duplicate-record-confirmation.js');
    this.dialog.open(DuplicateRecordConfirmation, {
      width: '500px', enterAnimationDuration: '0ms', exitAnimationDuration: '0ms',
    }).afterClosed().subscribe(isConfirmedDuplicateEntry => {
      if (isConfirmedDuplicateEntry === '1') {
        this.onSubmitReport('1');
      }
    });
  }
}
