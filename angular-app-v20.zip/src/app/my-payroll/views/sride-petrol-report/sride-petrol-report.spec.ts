import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SridePetrolReport } from './sride-petrol-report';

describe('SridePetrolReport', () => {
  let component: SridePetrolReport;
  let fixture: ComponentFixture<SridePetrolReport>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SridePetrolReport]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SridePetrolReport);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
