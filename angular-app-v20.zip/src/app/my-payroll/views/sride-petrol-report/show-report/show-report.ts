import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { PayrollService } from 'app/my-payroll/services/payroll-service.js';
import { ReportDetails } from '../report-details/report-details.js';
import { AsyncPipe, NgComponentOutlet } from '@angular/common';

@Component({
  selector: 'app-show-report',
  imports: [AsyncPipe, MatFormFieldModule, MatSelectModule, FormsModule, ReactiveFormsModule, MatInputModule,
    MatButtonModule, NgComponentOutlet],
  templateUrl: './show-report.html',
  styleUrl: './show-report.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ShowReport implements OnInit {
  private readonly payrollService = inject(PayrollService);
  private readonly cdr = inject(ChangeDetectorRef);
  protected readonly listOfYearsMonths$ = this.payrollService.getListOfYearsMonths();

  protected showReportForm!: FormGroup;
  protected reportDetailsComp!: (new() => ReportDetails) | null;
  protected reportDetailsInputs!: Record<string, any> | null;

  ngOnInit(): void {
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    //const currentMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).toLocaleString('en-US', { month: 'long' });
    this.showReportForm = new FormGroup({
      reportDate: new FormControl(`${currentYear}`, Validators.required),
      reportType: new FormControl('srideIncome', Validators.required)
    });
  }

  async onSubmitReport() {
    const { ReportDetails } = await import('../report-details/report-details.js');
    this.reportDetailsComp = ReportDetails;
    this.reportDetailsInputs = {
      searchParams: {...this.showReportForm.value}
    }
    this.cdr.detectChanges();
  }

  onClearReport() {
    this.reportDetailsComp = null;
    this.reportDetailsInputs = null;
  }
}
