import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowReport } from './show-report';

describe('ShowReport', () => {
  let component: ShowReport;
  let fixture: ComponentFixture<ShowReport>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShowReport]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowReport);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
