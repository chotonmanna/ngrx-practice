import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthPayroll } from './auth-payroll';

describe('AuthPayroll', () => {
  let component: AuthPayroll;
  let fixture: ComponentFixture<AuthPayroll>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AuthPayroll]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AuthPayroll);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
