import { Component, OnInit, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogActions, MatDialogClose, MatDialogTitle, MatDialogContent, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { Router } from '@angular/router';
import { PayrollService } from 'app/my-payroll/services/payroll-service.js';

@Component({
  selector: 'app-auth-payroll',
  imports: [MatButtonModule, MatDialogActions, MatDialogClose, MatDialogTitle, MatDialogContent, MatFormFieldModule,
    MatInputModule, ReactiveFormsModule],
  templateUrl: './auth-payroll.html',
  styleUrl: './auth-payroll.scss'
})
export class AuthPayroll implements OnInit {
  protected authForm!: FormGroup;
  private readonly payrollService = inject(PayrollService);
  private readonly router = inject(Router);
  private readonly dialogRef = inject(MatDialogRef<AuthPayroll>);

  ngOnInit(): void {
    this.authForm = new FormGroup({
      username: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required)
    })
  }

  onSubmitAuth() {
    if (this.authForm.valid) {
      this.payrollService.postAuthentication(this.authForm.value).subscribe(resp => {
        if (resp === '1') {
          this.dialogRef.close();
          this.router.navigateByUrl('my-payroll');
        }
      });
    }
  }
}
