import { Component } from '@angular/core';

@Component({
  selector: 'app-sbi-credit-card-report',
  imports: [],
  templateUrl: './sbi-credit-card-report.html',
  styleUrl: './sbi-credit-card-report.scss'
})
export class SbiCreditCardReport {

}
