import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SbiCreditCardReport } from './sbi-credit-card-report';

describe('SbiCreditCardReport', () => {
  let component: SbiCreditCardReport;
  let fixture: ComponentFixture<SbiCreditCardReport>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SbiCreditCardReport]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SbiCreditCardReport);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
