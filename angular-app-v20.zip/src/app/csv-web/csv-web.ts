import { Component, OnInit, computed, effect, inject } from '@angular/core';
import { DataProcess } from './services/data-process.js';
import { toSignal } from '@angular/core/rxjs-interop';
import { SettingsBoxDirective } from './directives/settings-box.js';
import { SettingBoxService } from './services/setting-box.js';

@Component({
  selector: 'app-csv-web',
  imports: [SettingsBoxDirective],
  providers: [DataProcess, SettingBoxService],
  templateUrl: './csv-web.html',
  styleUrl: './csv-web.scss'
})
export class CsvWeb implements OnInit {
  private readonly dataProcessService = inject(DataProcess);

  protected readonly arraySignal = toSignal(this.dataProcessService.getTextData());
  protected readonly headers = computed(() => {
    if (this.arraySignal()) {
      return Object.keys(this.arraySignal()![0]);
    }

    return [];
  });

  constructor() {
    effect(() => {
      
    })
  }

  ngOnInit(): void {
  }

  
}
