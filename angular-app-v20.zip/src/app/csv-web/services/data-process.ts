import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, catchError, map } from 'rxjs';

export type UnknownObjectModel = Record<string, string>;
interface HelperDataModel {
  totalNoRows: number;
  totalNoPages: number;
  listOfPages: Record<string, UnknownObjectModel[]>;
}

@Injectable()
export class DataProcess {
  private readonly http = inject(HttpClient);

  getTextData(): Observable<UnknownObjectModel[]> {
    return this.http.get('http://localhost:4300/files/1.txt', { responseType: 'text' })
      .pipe(
        map(resp => this.generateArrayOfObjectFromText(resp)),
        catchError(() => [])
      )
  }

  private generateArrayOfObjectFromText(text: string): UnknownObjectModel[] {
    // get total row number
    const { totalNoRows, totalNoPages, listOfPages } = this.getSomeHelperDataFromText(text);
    const masterRecords = [];

    for (let row = 1; row <= totalNoRows; row++) {
      let rowObject = {};
      for (let page = 1; page <= totalNoPages; page++) {
        const listOfPage = listOfPages['PAGE' + page];
        const index = listOfPage.findIndex(p => p['ROWNO'] === row.toString());
        if (index > -1) {
          rowObject = { ...rowObject, ...listOfPage[index] };
        }
      }

      masterRecords.push(rowObject);
    }

    return masterRecords;
  }

  private getSomeHelperDataFromText(text: string): HelperDataModel {
    text = text.replaceAll('!', '|');
    const getRowsLine = RegExp(/^0SUCCESSFUL RETRIEVAL OF\s+\d+\s+ROW\(S\)$/m).exec(text);
    const obj = {} as HelperDataModel;
    if (getRowsLine?.length) {
      const match = RegExp(/\d+/).exec(getRowsLine[0].replace('0SUCCESSFUL RETRIEVAL OF', ''));
      const arr = text.split('1PAGE')
      const listOfPages: Record<string, UnknownObjectModel[]> = {}
      const slicedArray = arr.slice(1, arr.length);
      slicedArray.forEach((line, i) => {
        listOfPages[`PAGE${i + 1}`] = this.createArrayFromTableLines(line);
      });

      obj.totalNoRows = match ? parseInt(match[0]) : 0;
      obj.listOfPages = listOfPages;
      obj.totalNoPages = slicedArray.length;
    }
    return obj;
  }

  private createArrayFromTableLines(line: string): UnknownObjectModel[] {
    const rows = line.split('\r\n').filter(row => row.includes('|')).map(row => row.trim());
    const arrayFromTable: UnknownObjectModel[] = [];
    const arrayOfHeaders = rows[0].slice(0, -1).split('|').map(row => row.trim());
    rows.slice(1, rows.length).forEach(elem => {
      const arrayObject: UnknownObjectModel = {};
      const arrayOfValues = elem.slice(0, -1).split('|').map(row => row.trim());
      arrayOfValues.forEach((value, i) => {
        arrayObject[arrayOfHeaders[i] || 'ROWNO'] = value.includes('_') ? value.split('_')[0] : value;
      });
      arrayFromTable.push(arrayObject);
    });

    return arrayFromTable;
  }
}
