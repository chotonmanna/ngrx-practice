import { Injectable, signal } from '@angular/core';

@Injectable()
export class SettingBoxService {
  private readonly lastStoredSettingBoxRef = signal<HTMLElement | null>(null);

  saveLastStoredSettingBoxRef(elem: HTMLElement) {
    this.lastStoredSettingBoxRef.set(elem);
  }

  getLastStoredSettingBoxRef(): HTMLElement | null {
    const refValue =  this.lastStoredSettingBoxRef();
    this.lastStoredSettingBoxRef.set(null);
    return refValue;
  }
}
