import { Component, Input, input } from '@angular/core';
import { ClickoutsideDirective } from 'app/csv-web/directives/clickoutside.js';

@Component({
  selector: 'app-settings-box',
  imports: [],
  templateUrl: './settings-box.html',
  styleUrl: './settings-box.scss',
  hostDirectives: [
    {
      directive: ClickoutsideDirective
    }
  ]
})
export class SettingsBoxComponent {
  @Input() boxPositionStyles!: { left: string; top: string; };
  public text = input.required<string>();
}
