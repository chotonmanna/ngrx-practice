import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SettingsBox } from './settings-box';

describe('SettingsBox', () => {
  let component: SettingsBox;
  let fixture: ComponentFixture<SettingsBox>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SettingsBox]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SettingsBox);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
