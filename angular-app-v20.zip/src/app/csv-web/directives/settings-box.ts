import { Directive, inject, ViewContainerRef, EmbeddedViewRef, input, ElementRef } from '@angular/core';
import { SettingsBoxComponent } from '../components/settings-box/settings-box.js';
import { SettingBoxService } from '../services/setting-box.js';

@Directive({
  selector: '[appSettingsBox]',
  host: {
    '(contextmenu)': 'onRightClick($event)',
    '(mouseenter)': 'onMouseEnter()',
    '(mouseleave)': 'onMouseLeave()'
  }
})
export class SettingsBoxDirective {
  private readonly viewContainerRef = inject(ViewContainerRef);
  private readonly settingBoxService = inject(SettingBoxService);
  private readonly elemRef = inject(ElementRef);

  public readonly appSettingsBox = input.required<string>();

  onMouseEnter() {
    this.elemRef.nativeElement.style.cursor = 'context-menu';
    this.elemRef.nativeElement.style.backgroundColor = '#eee9e9';
  }

  onMouseLeave() {
    this.elemRef.nativeElement.style.cursor = 'initial';
    this.elemRef.nativeElement.style.backgroundColor = 'initial';
  }

  onRightClick(e: MouseEvent) {
    e.preventDefault();

    if (this.settingBoxService.getLastStoredSettingBoxRef()) {
      document.body.removeChild(this.settingBoxService.getLastStoredSettingBoxRef()!);
    }
    
    const componentRef = this.viewContainerRef.createComponent(SettingsBoxComponent);
    componentRef.instance.boxPositionStyles = { left: `${e.pageX}px`, top: `${e.pageY}px` };
    componentRef.instance.text = this.appSettingsBox;
    const domElem = (componentRef.hostView as EmbeddedViewRef<any>).rootNodes[0] as HTMLElement;
    
    document.body.appendChild(domElem);

    this.settingBoxService.saveLastStoredSettingBoxRef(domElem);
  }


}
