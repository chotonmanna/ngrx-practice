import { Directive, ElementRef, HostListener, inject } from '@angular/core';
import { SettingBoxService } from '../services/setting-box.js';

@Directive({
  selector: '[appClickoutside]'
})
export class ClickoutsideDirective {
  private readonly elemRef = inject(ElementRef);
  private readonly settingBoxService = inject(SettingBoxService);

  @HostListener('document:click', ['$event'])
  public onClick(e: any) {
    if (!this.elemRef.nativeElement.contains(e.target)) {
      if (this.settingBoxService.getLastStoredSettingBoxRef()) {
        document.body.removeChild(this.settingBoxService.getLastStoredSettingBoxRef()!);
      }
    }
  }

}
