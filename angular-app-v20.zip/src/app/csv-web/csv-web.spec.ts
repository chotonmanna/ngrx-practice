import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CsvWeb } from './csv-web';

describe('CsvWeb', () => {
  let component: CsvWeb;
  let fixture: ComponentFixture<CsvWeb>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CsvWeb]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CsvWeb);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
