import { Component, OnInit, computed, contentChild, inject, signal, viewChild } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute, ActivationEnd, NavigationEnd, NavigationStart, Router, RouterLink, RouterOutlet } from '@angular/router';
import { Observable, filter } from 'rxjs';
import { ENV_CONFIG, LOCAL_STORAGE } from './env.config.js';
// import { MyInfo } from './my-info/my-info.js';
// import { AdminInfo } from './admin-info/admin-info.js';
//import { NgComponentOutlet } from '@angular/common';
//import { AdminInfo } from './admin-info/admin-info.js';
//import { MyInfo } from './my-info/my-info.js';
// import { HostElement } from './host-element/host-element.js';
// import { HelloWorld } from "./hello-world/hello-world.js";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink], // NgComponentOutlet
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App implements OnInit {
  // private readonly envConfigValue = inject(ENV_CONFIG);
  // private readonly lStorage = inject(LOCAL_STORAGE);
  protected readonly featureLinks = [
    'templates/ng-container',
    'templates/defer',
    'directives',
    'ecommerce',
    'csv-web',
    'my-payroll'
  ];
  protected readonly leftMenuHiddenFor = ['csv-web', 'my-payroll'];
  private readonly aRoute = inject(ActivatedRoute);
  private readonly route = inject(Router);

  protected readonly routeEventAsSignal = toSignal(this.route.events.pipe(filter(e => e instanceof NavigationEnd)));
  protected readonly currentUrl = computed(() => {
    if (this.routeEventAsSignal()) {
      const url = (this.routeEventAsSignal() as NavigationEnd)?.url;
      return url.slice(1, url.length);
    }
    
    return undefined;
  });

  protected readonly willDisplayLeftMenu = computed(() => {
    return this.currentUrl() ? !this.leftMenuHiddenFor.some(menu => this.currentUrl()?.includes(menu)) : true;
  });
  // protected readonly title = signal('angular-app-v20');
  // protected myAge = 35;
  // protected isDisplayed = signal(false);
  // protected readonly myInfoComp = viewChild(MyInfo);
  // protected readonly myInfoName = computed(() => this.myInfoComp()?.fname);

  // protected readonly myInfoCont = contentChild(MyInfo);

  //protected infoType = signal<string>('admin');
  // protected readonly infoTypeComp = computed(async () => {
  //   if (this.infoType() === 'admin') {
  //     const {AdminInfo} = await import('./admin-info/admin-info.js');
  //     return AdminInfo;
  //   } else {
  //     const {MyInfo} = await import('./my-info/my-info.js');
  //     return MyInfo;
  //   }
  // });

  //adminInfoComp!: new() => AdminInfo;
  
  // handler() {
  //   console.log('age changed');
  // }

  ngOnInit(): void {
    // this.lStorage.setItem('name', 'Biswajit Manna');
    // setTimeout(() => {
    //   console.log(this.lStorage.getItem('name'));
    // }, 2000);
    // console.log(this.envConfigValue.estarterApiEndpoint);

    //  this.route.events.pipe(filter(e => e instanceof NavigationEnd))
    //   .subscribe((e: NavigationEnd) => {
    //     this.currentUrl.set(e.url)
    //   })


    // setTimeout(() => {
    //   console.log('display changed');
    //   this.isDisplayed.set(true);
    // }, 5000);
    
    //console.log('here....', this.myInfoName());
  }

  // protected onClickToggleInfo() {
  //   this.infoType.update(val => val === 'admin' ? 'my' : 'admin');
  // }

  // protected async onClickLoadAdminInfo() {
  //   const {AdminInfo} = await import('./admin-info/admin-info.js');
  //   this.adminInfoComp = AdminInfo;
  // }
}
