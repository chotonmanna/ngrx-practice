import { ApplicationConfig, inject, provideAppInitializer, provideBrowserGlobalErrorListeners, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes.js';
import { provideHttpClient } from '@angular/common/http';
import { EnvConfigService } from './services/env-config.service.js';
import { ENV_CONFIG, LOCAL_STORAGE } from './env.config.js';
import { BASE_API_URL, SESSION_STORAGE } from './my-payroll/payroll.config.js';

// Get config info based on environment

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideHttpClient(),
    // provideAppInitializer(() => {
    //   const envConfigService = inject(EnvConfigService);
    //   return envConfigService.loadConfig();
    // }),
    // {
    //   provide: ENV_CONFIG,
    //   useFactory: (config: EnvConfigService) => config.getConfig(),
    //   deps: [EnvConfigService]
    // },
    {
      provide: LOCAL_STORAGE,
      useValue: localStorage
    },
    {
      provide: BASE_API_URL,
      useValue: 'http://localhost:3000/api'
    },
    {
      provide: SESSION_STORAGE,
      useValue: sessionStorage
    }
  ]
};
