import { InjectionToken } from "@angular/core";

export interface EnvConfig {
	version: string;
	estarterApiEndpoint: string;
	environment: string;
	activate: boolean;
  defaultCount: number;
}

export const ENV_CONFIG = new InjectionToken<EnvConfig>('env.config');

export const LOCAL_STORAGE = new InjectionToken<Storage>('local.storage');
