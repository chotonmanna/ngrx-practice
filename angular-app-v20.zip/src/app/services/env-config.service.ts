import { HttpClient } from '@angular/common/http';
import { DOCUMENT, Injectable, inject, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EnvConfig } from 'app/env.config.js';
import { firstValueFrom, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EnvConfigService {
  private readonly configValues = signal<EnvConfig | null>(null);
  private readonly http = inject(HttpClient);
  private readonly document = inject(DOCUMENT);

  loadConfig(): Promise<EnvConfig> {
    const currentUrl = new URL(this.document.URL);
    const params = Object.fromEntries(currentUrl.searchParams.entries());
    return firstValueFrom(
      this.http.get<EnvConfig>(`./env-config/config-${params['env']}.json`).pipe(
        tap(value => {
          this.configValues.set(value);
        })
      )
    )
  }

  getConfig(): EnvConfig | null {
    return this.configValues();
  }
}
