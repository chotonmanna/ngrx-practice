import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-info',
  imports: [],
  templateUrl: './admin-info.html',
  styleUrl: './admin-info.scss'
})
export class AdminInfo {

}
