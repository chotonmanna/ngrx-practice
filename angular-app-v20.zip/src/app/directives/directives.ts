import { Component } from '@angular/core';
import { MyDir } from './my-dir.js';
import { HostDirectiveComp } from './host-directive-comp/host-directive-comp.js';

@Component({
  selector: 'app-directives',
  imports: [MyDir, HostDirectiveComp],
  templateUrl: './directives.html',
  styleUrl: './directives.scss'
})
export class Directives {
  onDisplayName(e: string) {
    console.log(e);
  }
}
