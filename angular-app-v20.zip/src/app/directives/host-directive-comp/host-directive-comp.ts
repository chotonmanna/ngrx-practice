import { Component, OnInit, input } from '@angular/core';
import { MyHostDir } from '../my-host-dir.js';

@Component({
  selector: 'app-host-directive-comp',
  imports: [],
  templateUrl: './host-directive-comp.html',
  styleUrl: './host-directive-comp.scss',
  hostDirectives: [{
    directive: MyHostDir,
    inputs: ['name', 'color'],
    outputs: ['showName']
  }]
})
export class HostDirectiveComp implements OnInit {
  name = input.required<string>();
  color = input.required<string>();

  constructor() {
    
  }

  ngOnInit(): void {
    console.log(this.name(), this.color());
  }
}
