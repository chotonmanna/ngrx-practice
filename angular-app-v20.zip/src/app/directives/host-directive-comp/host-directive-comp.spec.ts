import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HostDirectiveComp } from './host-directive-comp';

describe('HostDirectiveComp', () => {
  let component: HostDirectiveComp;
  let fixture: ComponentFixture<HostDirectiveComp>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HostDirectiveComp]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HostDirectiveComp);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
