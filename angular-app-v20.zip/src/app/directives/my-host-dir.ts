import { Directive, EventEmitter, HostBinding, Input, Output } from '@angular/core';

@Directive({
  selector: '[appMyHostDir]',
  host: {
    '(click)': 'onClick()',
    '[style.color]': 'color'
  }
})
export class MyHostDir {
  @Input() name!: string;
  @Output() showName = new EventEmitter<string>();
  @Input() color!: string;
  //@HostBinding('style.color') @Input() color!: string

  constructor() { }

  onClick() {
   this.showName.emit(`My name is ${this.name}`);
  }

}
