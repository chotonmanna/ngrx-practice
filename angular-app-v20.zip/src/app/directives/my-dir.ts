import { Directive, ElementRef, HostListener, ViewContainerRef, inject, input } from '@angular/core';
import { Tooltip } from './tooltip/tooltip.js';

@Directive({
  selector: '[appMyDir]'
})
export class MyDir {
  private readonly elementRef = inject(ElementRef);
  private readonly containerRef = inject(ViewContainerRef);
  public readonly appMyDir = input.required<string>();

  constructor() {
    this.elementRef.nativeElement.style = {
      'color': 'green',
      'fontWeight': 'bold'
    }
  }

  @HostListener('mouseenter') onMouseEnter() {
    this.containerRef.createComponent(Tooltip).instance.msg = this.appMyDir;
  }

  @HostListener('mouseleave') onMouseLeave() {
    this.containerRef.remove();
  }

}
