const express = require('express');
const cors = require('cors');
const payrollRouter = require('./payroll/router');

const app = express();
const port = 3000;

// Enable CORS (Cross-Origin Resource Sharing)
app.use(cors());

// Middleware to parse JSON bodies
app.use(express.json());

// A simple API endpoint
app.get('/api/hello', (req, res) => {
  res.json({ message: 'Hello from Node.js API' });
});

app.use('/api/payroll', payrollRouter);

// Start the server
app.listen(port, () => {
  console.log(`API server running at http://localhost:${port}`);
});