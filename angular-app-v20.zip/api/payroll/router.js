const express = require('express');
const { addAllExpenseAndIncomeDetails, getListOfYearMonth, getListOfReports, authentication } = require('./services');
const payrollRouter = express.Router();

payrollRouter.post('/add-expense-income', addAllExpenseAndIncomeDetails);
payrollRouter.get('/listof-year-month', getListOfYearMonth);
payrollRouter.get('/get-reports/:reportDate/:reportType', getListOfReports)
payrollRouter.post('/authentication', authentication)

module.exports = payrollRouter;