const fs = require('fs');
const path = require('path');
const fsAsPromise = require('fs/promises');

const addAllExpenseAndIncomeDetails = (req, res) => {
  const obj = req.body;
  const splittedDate = obj.reportDate.split('-');
  const folder = `data/${parseInt(splittedDate[0])}`;

  try {
    // First check if folder exist or not
    if (!fs.existsSync(folder)) {
      fs.mkdirSync(folder, { recursive: true });
    }

    const file = `${parseInt(splittedDate[1])}.json`;
    const filePath = path.join(folder, file);

    // Then check if json file exist or not
    let records = [];
    if (fs.existsSync(filePath)) {
      records = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }

    // before insert check duplicate record exist
    const existingRecord = records.filter(row => (row.reportDate === obj.reportDate && row.reportType === obj.reportType));
    const isDuplicateEntry = !!existingRecord?.length;

    if (isDuplicateEntry && obj.isConfirmedDuplicateEntry === '0') {
      res.status(400).send({ status: 'duplicate', type: '2', data: existingRecord });
    }

    if (!isDuplicateEntry || (isDuplicateEntry && obj.isConfirmedDuplicateEntry === '1')) {
      // Delete isConfirmedDuplicateEntry
      delete obj.isConfirmedDuplicateEntry;
      records.push(obj);
      fs.writeFileSync(filePath, JSON.stringify(records));
      res.status(200).send({ status: 'success', type: '1' });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({ status: 'failed', type: '0' });
  }
};

const getListOfYearMonth = async (req, res) => {
  const listOfYearDir = await fsAsPromise.readdir('./data', { withFileTypes: true });
  const data = [];
  for (const yDir of listOfYearDir) {
    const year = yDir.name;
    // const listOfMonthFiles = await fsAsPromise.readdir(`./data/${year}`, { withFileTypes: true });
    // const months = [];
    // for (const mFile of listOfMonthFiles) {
    //   const monthNumber = parseInt(mFile.name.split('.')[0]);
    //   months.push(monthNumber);
    //   months.sort((a, b) => a - b);
    // }
    // months: months.map(monthNumber => getMonthNameFromMonthNumber(monthNumber))

    data.push(year);
  }
  res.status(200).send({ status: 'success', data });
}

const getListOfReports = async (req, res) => {
  const { reportDate, reportType } = req.params;
  let year, month, results = {}, yearlyPetrolExpenseViaRP = 0;

  // if (reportDate.includes('-')) {
  //   const splittedValue = reportDate.split('-');
  //   year = splittedValue[0];
  //   month = splittedValue[1];
  // } else {
    year = reportDate;
  //}

  results = { ...results, year };

  // Get list of files of month from selected year
  const listOfMonthFiles = await fsAsPromise.readdir(`./data/${year}`, { withFileTypes: true });
  let reports = [];

  for (const mFile of listOfMonthFiles) {
    const filePath = path.join(`./data/${year}`, mFile.name);

    // Then check if json file exist or not
    let monthlyData = [];
    if (fs.existsSync(filePath)) {
      monthlyData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }

    // Filter data by report type
    if (reportType !== 'all') {
      monthlyData = monthlyData.filter(obj => obj.reportType === reportType);
    }

    //Sort with report date
    monthlyData.sort((obj1, obj2) => (new Date(obj1.reportDate) - new Date(obj2.reportDate)));

    let monthlyObject = { month: parseInt(mFile.name.split('.')[0]), data: monthlyData };

    if (['all', 'srideIncome'].includes(reportType)) {
      monthlyObject = {
        ...monthlyObject,
        monthlySrideIncome: monthlyData.filter(obj => obj.reportType === 'srideIncome').reduce((total, item) => total + item.amount, 0)
      };
    }

    if (['all', 'petrolExpense'].includes(reportType)) {
      monthlyObject = {
        ...monthlyObject,
        monthlyPetrolExpense: monthlyData.filter(obj => obj.reportType === 'petrolExpense' && !obj.viaRewardPoints).reduce((total, item) => total + item.amount, 0)
      };

      yearlyPetrolExpenseViaRP = yearlyPetrolExpenseViaRP + monthlyData.filter(obj => obj.reportType === 'petrolExpense' && obj.viaRewardPoints).reduce((total, item) => total + item.amount, 0)
    }

    reports.push(monthlyObject);
  }

  // Sort reports with month
  reports.sort((a, b) => a.month - b.month);
  reports = reports.map(r => ({ ...r, month: getMonthNameFromMonthNumber(r.month) }));

  // Filter data by report month
  // if (month) {
  //   reports = reports.filter(obj => obj.month === month);
  // }

  results = {
    ...results,
    yearlySrideIncome: ['all', 'srideIncome'].includes(reportType) ? reports.reduce((total, item) => (total + item.monthlySrideIncome), 0) : undefined,
    yearlyPetrolExpense: ['all', 'petrolExpense'].includes(reportType) ? reports.reduce((total, item) => (total + item.monthlyPetrolExpense), 0) : undefined,
    yearlyPetrolExpenseViaRP: ['all', 'petrolExpense'].includes(reportType) ? yearlyPetrolExpenseViaRP : undefined,
    reports
  };
  res.status(200).send({ data: results, status: 'success' });
}

const getMonthNameFromMonthNumber = (monthNumber) => {
  return new Date(2000, monthNumber - 1, 1).toLocaleString('en-US', { month: 'long' });
}

const authentication = (req, res) => {
  const { username, password } = req.body;

  if (username === 'biswajit' && atob(password) === 'nopass') {
    res.status(200).send({ status: 'success', type: '1' });
  } else {
    res.status(401).send({ status: 'failed', type: '1' });
  }
}

module.exports = {
  addAllExpenseAndIncomeDetails,
  getListOfYearMonth,
  getListOfReports,
  authentication
}
