import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyCustomElemComponent } from './my-custom-elem.component';

describe('MyCustomElemComponent', () => {
  let component: MyCustomElemComponent;
  let fixture: ComponentFixture<MyCustomElemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MyCustomElemComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyCustomElemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
