import { Component } from '@angular/core';

@Component({
  selector: 'app-my-custom-elem',
  templateUrl: './my-custom-elem.component.html',
  styleUrl: './my-custom-elem.component.scss'
})
export class MyCustomElemComponent {

}
