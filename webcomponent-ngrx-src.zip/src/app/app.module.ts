import { ApplicationRef, CUSTOM_ELEMENTS_SCHEMA, DoBootstrap, Injector, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HelloWorldComponent } from './hello-world/hello-world.component';
import { createCustomElement } from '@angular/elements';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MyCustomElemComponent } from './my-custom-elem/my-custom-elem.component';

@NgModule({
  declarations: [
    AppComponent,
    HelloWorldComponent,
    MyCustomElemComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule implements DoBootstrap { 

  constructor(
    private injector: Injector
  ) { }

  ngDoBootstrap(appRef: ApplicationRef): void {
    customElements.define('hello-world', createCustomElement(HelloWorldComponent, {injector: this.injector}));
    customElements.define('my-customelem', createCustomElement(MyCustomElemComponent, {injector: this.injector}));
    appRef.bootstrap(AppComponent);
  }
}
