export function truncateDecimals(number: number, digits: number): number {
  const multiplier = Math.pow(10, digits);
  const adjustedNum = number * multiplier;
  const truncatedNum = Math[adjustedNum < 0 ? 'ceil' : 'floor'](adjustedNum);

  return truncatedNum / multiplier;
}

export const numberToFixed = (value: number | string): string => {
  return (Math.round(Number(value) * 100) / 100).toFixed(2);
};
