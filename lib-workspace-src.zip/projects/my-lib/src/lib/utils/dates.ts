export const getMonthDiffWithDays = (d1: Date | null = null, d2: Date | null = null): number => {
  const date1 = d1 ? new Date(d1) : new Date();
  const date2 = d2 ? new Date(d2) : new Date();
  const difD = date2.getDate() - date1.getDate();
  const difM = date2.getMonth() - date1.getMonth();
  const r = difD / 30 + difM + 12 * (date2.getFullYear() - date1.getFullYear());
  return Math.abs(r);
}

export const getYearsDiff = (d1: Date | null = null, d2: Date | null = null): number => {
  const date1 = d1 ? new Date(d1) : new Date();
  const date2 = d2 ? new Date(d2) : new Date();
  const yearsDiff = date2.getFullYear() - date1.getFullYear();
  return yearsDiff;
}

export const getMonthDiff = (d1: Date | null = null, d2: Date | null = null) => {
  const date1 = d1 ? new Date(d1) : new Date();
  const date2 = d2 ? new Date(d2) : new Date();
  const years = getYearsDiff(date1, date2);
  const months = years * 12 + (date2.getMonth() - date1.getMonth());

  return Math.abs(months);
}

export const isValidDate = (dateInput: string): boolean => {
  let dateArray = dateInput.split("/");
  return !isNaN(new Date(`${dateArray[2]}/${dateArray[1]}/${dateArray[0]}`).getTime());
}