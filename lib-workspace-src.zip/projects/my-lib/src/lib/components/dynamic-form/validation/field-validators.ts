import { ValidatorFn, AbstractControl, ValidationErrors } from "@angular/forms";
import { getMonthDiff } from "../../../utils/dates";
import { truncateDecimals, numberToFixed } from "../../../utils/numbers";
import { StoreDataService } from "../../../services/store-data.service";

export const validateMinDate = (minDate: string): ValidatorFn => {
  return (control: AbstractControl) => {
    let error: ValidationErrors | null = { EAUTO_P1_SC3_ERROR_DATE_LIMIT_VALUE: true };
    if (control.valid) {
      const fieldValue = control.value as string;
      if (fieldValue?.length > 10) {
        error = { ELIB_ERROR_VALID_DATE: true };
      } else {
        const fieldValueDateFormated = new Date(fieldValue);
        const dataToCompare = new Date(minDate);
        if (!(fieldValueDateFormated < dataToCompare)) {
          error = null;
        }
      }
    }
    return error;
  }
}

// export const validateMaxDate = () => {

// }