import { Component, Input, OnInit } from '@angular/core';
import { ControlContainer, FormGroupDirective, UntypedFormControl, ValidatorFn } from '@angular/forms';

type ErrorType = 'required' | 'email';

@Component({
  selector: 'app-field-validation',
  templateUrl: './field-validation.component.html',
  styleUrls: ['./field-validation.component.scss'],
  viewProviders: [{ provide: ControlContainer, useExisting: FormGroupDirective }]
})
export class FieldValidationComponent implements OnInit {
  @Input() name!: string;
  @Input() validators!: Array<ValidatorFn | { type: ValidatorFn, msg: string }>;

  defaultErrorMsg: { [K in ErrorType]: string } = {
    email: 'Invalid email',
    required: 'This field is required',
    //ELIB_ERROR_VALID_DATE: 'La date de 1ere mise en circulation doit dater daprès 2002.'
  }

  constructor(
    private parentForm: FormGroupDirective
  ) { }

  ngOnInit(): void {
    // Override default messages with custom messages
  }

  getFieldErrors(): string[] {
    let fieldErrors: string[] = [];
    const { touched, dirty, invalid, errors } = this.parentForm.form.get(this.name) as UntypedFormControl;

    if (!!((touched || dirty) && (errors || invalid))) {
      fieldErrors = Object.keys(errors as { [key: string]: string });
    }

    // if (fieldErrors.length) {
    //   fieldErrors = fieldErrors.map(e => this.defaultErrorMsg[e as ErrorType]);
    // }

    return fieldErrors;
  }
}
