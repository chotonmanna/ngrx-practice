import { ChangeDetectionStrategy, Component, OnInit, forwardRef } from '@angular/core';
import { DropdownControlConfig } from '../../models/dropdown-config.model';
import { Observable, isObservable, of } from 'rxjs';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { BaseControlComponent } from '../base-field.component';
import { FieldsConfigService } from '../../fields-config.service';
import { IOption } from '../../models/radio-config.model';

@Component({
  selector: 'app-field-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => DropdownComponent)
    }
  ]
})
export class DropdownComponent extends BaseControlComponent<DropdownControlConfig> {
  constructor(
    protected override fieldConfigService: FieldsConfigService
  ) {
    super(fieldConfigService);
  }

  getOptionValues(options: Observable<IOption[]> | IOption[]) {
    return isObservable(options) ? options : of(options);
  }
}
