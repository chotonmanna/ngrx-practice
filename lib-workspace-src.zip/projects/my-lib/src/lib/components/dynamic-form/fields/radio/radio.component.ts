import { Component, OnInit, forwardRef } from '@angular/core';
import { RadioControlConfig } from '../../models/radio-config.model';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { BaseControlComponent } from '../base-field.component';
import { FieldsConfigService } from '../../fields-config.service';

@Component({
  selector: 'app-field-radio',
  templateUrl: './radio.component.html',
  styleUrls: ['./radio.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => RadioComponent)
    }
  ]
})
export class RadioComponent extends BaseControlComponent<RadioControlConfig> {

  constructor(
    protected override fieldConfigService: FieldsConfigService
  ) {
    super(fieldConfigService);
  }

}
