import { Component, forwardRef } from '@angular/core';
import { NumberControlConfig } from '../../models/number-config.model';
import { NG_VALUE_ACCESSOR, NG_VALIDATORS } from '@angular/forms';
import { FieldsConfigService } from '../../fields-config.service';
import { BaseControlComponent } from '../base-field.component';

@Component({
  selector: 'app-field-numberbox',
  templateUrl: './number.component.html',
  styleUrls: ['./number.component.scss', '../text/text.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => NumberComponent)
    },
    {
      provide: NG_VALIDATORS,
      multi: true,
      useExisting: NumberComponent
    }
  ]
})
export class NumberComponent extends BaseControlComponent<NumberControlConfig> {
  constructor(
    protected override fieldConfigService: FieldsConfigService
  ) {
    super(fieldConfigService);
  }

  handleKeyDown(e: KeyboardEvent): void {
    const value: string | number = String((e.target as HTMLInputElement).value) || '';
    const key = e.key ?? '';

    // If maxlength is defined
    if (this.config?.maxLength && value.length >= this.config.maxLength && key.length === 1) {
      e.preventDefault();
    }
  }

}
