import { ChangeDetectionStrategy, Component, OnInit, forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, FormGroup, FormControl, Validators, AbstractControl, ValidationErrors, ControlValueAccessor, NG_VALIDATORS, Validator } from '@angular/forms';
import { BehaviorSubject, Subject, Subscription, debounceTime, distinctUntilChanged, takeUntil } from 'rxjs';
import { FieldsConfigService } from '../../fields-config.service';
import { TextboxControlConfig } from '../../models/textbox-config.model';
import { Store } from '@ngrx/store';
import { PostalAddress } from '../../../../models/ScreenAttributes';
import { BaseAppState } from '../../../../models/BaseAppState';
import { streetProposalActions, cityProposalActions } from '../../../../store/postal-address/actions';
import { selectCityProposal } from '../../../../store/postal-address/selectors';
import { NumberControlConfig } from '../../models';

const listOfCities = ['Howrah', 'Kolkata', 'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Pune']

@Component({
  selector: 'app-field-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.scss'],
  //changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => AddressComponent)
    },
    {
      provide: NG_VALIDATORS,
      multi: true,
      useExisting: forwardRef(() => AddressComponent)
    }
  ]
})
export class AddressComponent implements OnInit, ControlValueAccessor, Validator {
  addressForm!: FormGroup;
  cities$ = new BehaviorSubject<string[]>(listOfCities);

  onTouched: Function = () => { };
  private onChangeSubs: Subscription[] = [];
  private readonly unsubscribe$ = new Subject();

  constructor(
    private fieldConfigService: FieldsConfigService,
    private store: Store<BaseAppState>,
  ) { }

  ngOnInit(): void {
    this.addressForm = new FormGroup({
      zip: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]*$/)]),
      city: new FormControl('', Validators.required),
      street: new FormControl('', Validators.required),
      number: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]*$/)]),
      box: new FormControl('')
    });

    this.fieldConfigService.loadConfig({
      zip: new NumberControlConfig({
        label: 'ELIB_ADDRESS_POSTCODE_Q',
        placeholder: 'ELIB_ADDRESS_POSTCODE_PH',
        maxLength: 4
      }),
      city: new TextboxControlConfig({
        label: 'ELIB_ADDRESS_CITY_Q',
        placeholder: 'ELIB_ADDRESS_CITY_PH',
        autocomplete: this.store.select(selectCityProposal)
      }),
      street: new TextboxControlConfig({
        label: 'ELIB_ADDRESS_STREET_Q',
        placeholder: 'ELIB_ADDRESS_STREET_PH'
      }),
      number: new TextboxControlConfig({
        label: 'ELIB_ADDRESS_HOUSENUMBER_Q',
        placeholder: 'ELIB_ADDRESS_HOUSENUMBER_PH',
        maxLength: 5
      }),
      box: new NumberControlConfig({
        label: 'ELIB_ADDRESS_BOX_Q',
        placeholder: 'ELIB_ADDRESS_BOX_PH',
        maxLength: 3
      })
    });

    this.addressForm.get('street')?.valueChanges
      .pipe(debounceTime(400), distinctUntilChanged(), takeUntil(this.unsubscribe$))
      .subscribe(streetName => this.store.dispatch(streetProposalActions.load({ streetName })))
  }

  onChangeZip() {
    if (this.addressForm.get('zip')?.valid) {
      const postalCode = `${this.addressForm.get('zip')?.value}`;
      if (postalCode.length === 4) {
        this.store.dispatch(cityProposalActions.clear());
        this.store.dispatch(cityProposalActions.load({ postalCode }));
      }
    }
  }

  onChangeCity() {
    const postalCode = `${this.addressForm.get('zip')?.value}`;
    const city = this.addressForm.get('city')?.value;
    const dt = listOfCities.filter(c => c.toLowerCase().includes(city.toLowerCase()));
    console.log(dt);
    this.cities$.next(dt);
  }

  writeValue(value: PostalAddress) {
    value && this.addressForm.setValue(value);
  }

  registerOnChange(onChange: any) {
    const sub = this.addressForm.valueChanges.subscribe(onChange);
    this.onChangeSubs.push(sub);
  }

  registerOnTouched(onTouched: Function) {
    this.onTouched = onTouched;
  }

  setDisabledState(isDisabled: boolean) {
    if (isDisabled) {
      this.addressForm.disable();
    } else {
      this.addressForm.enable();
    }
  }

  validate(control: AbstractControl): ValidationErrors | null {
    if (control.hasValidator(Validators.required) && this.addressForm.invalid) {
      return { address: true };
    }

    return null;
  }

  ngOnDestroy() {
    for (let sub of this.onChangeSubs) {
      sub.unsubscribe();
    }
  }
}
