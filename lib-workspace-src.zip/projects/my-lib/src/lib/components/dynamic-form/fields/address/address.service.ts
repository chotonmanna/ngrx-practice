import { Injectable } from "@angular/core";
import { Observable, map } from "rxjs";
import { CityProposal } from "../../../../models/city";
import { HttpClientService } from "../../../../services/http/client.service";



@Injectable({
  providedIn: 'root'
})
export class AddressFieldService {

  constructor(
    private httpService: HttpClientService
  ) { }

  geCityProposal(postal_city_code: string): Observable<CityProposal[]> {
    return this.httpService.postRequest<CityProposal, { cities: CityProposal[] }>('postal/address/city/proposal', {
      postal_city_code, postal_country_code: '56'
    }).pipe(
      map(resp => resp.cities || [])
    );
  }

  // getStreetProposal(postal_code: string, postal_municipality_name: string, street_name: string): Observable<StreetProposal[]> {
  //   return this.httpService.postRequest
  // }

}