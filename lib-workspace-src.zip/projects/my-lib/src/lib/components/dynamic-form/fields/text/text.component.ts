import { Component, forwardRef } from "@angular/core";
import { NG_VALIDATORS, NG_VALUE_ACCESSOR } from "@angular/forms";
import { BaseControlComponent } from "../base-field.component";
import { TextboxControlConfig } from "../../models/textbox-config.model";
import { FieldsConfigService } from "../../fields-config.service";
import { Observable, isObservable, of } from "rxjs";

@Component({
  selector: 'app-field-textbox',
  templateUrl: './text.component.html',
  styleUrls: ['./text.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => TextBoxComponent)
    },
    {
      provide: NG_VALIDATORS,
      multi: true,
      useExisting: TextBoxComponent
    }
  ]
})
export class TextBoxComponent extends BaseControlComponent<TextboxControlConfig> {
  constructor(
    protected override fieldConfigService: FieldsConfigService
  ) {
    super(fieldConfigService);
  }

  getAutocompleteValues(options: Observable<string[]> | string[]) {
    return isObservable(options) ? options : of(options);
  }

  handleKeyDown(e: KeyboardEvent): void {
    const value: string | number = String((e.target as HTMLInputElement).value) || '';
    const key = e.key === null ? '' : e.key;

    if (['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight'].includes(key)) {
      return;
    }

    // If maxlength is defined
    if (this.config?.maxLength && value.length === this.config.maxLength) {
      e.preventDefault();
    }
  }
}
