import { ChangeDetectionStrategy, Component, OnInit, forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, FormGroup, FormControl, Validators, AbstractControl, ValidationErrors, ControlValueAccessor, NG_VALIDATORS, Validator } from '@angular/forms';
import { BehaviorSubject, Subject, Subscription, debounceTime, distinctUntilChanged, takeUntil } from 'rxjs';
import { FieldsConfigService } from '../../fields-config.service';
import { TextboxControlConfig } from '../../models/textbox-config.model';
import { Store } from '@ngrx/store';
import { PostalAddress } from '../../../../models/ScreenAttributes';
import { BaseAppState } from '../../../../models/BaseAppState';
import { streetProposalActions, cityProposalActions } from '../../../../store/postal-address/actions';
import { selectCityProposal } from '../../../../store/postal-address/selectors';
import { DateTimeControlConfig, RadioControlConfig } from '../../models';
import { DateTimeComponent } from '../datetime/datetime.component';

const listOfCities = ['Howrah', 'Kolkata', 'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Pune']

@Component({
  selector: 'app-field-personal-info',
  templateUrl: './personal-info.component.html',
  styleUrls: ['./personal-info.component.scss'],
  //changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => PersonalInfoComponent)
    },
    {
      provide: NG_VALIDATORS,
      multi: true,
      useExisting: forwardRef(() => PersonalInfoComponent)
    }
  ]
})
export class PersonalInfoComponent implements OnInit, ControlValueAccessor, Validator {
  personalInfoForm!: FormGroup;
  cities$ = new BehaviorSubject<string[]>(listOfCities);

  onTouched: Function = () => { };
  private onChangeSubs: Subscription[] = [];
  private readonly unsubscribe$ = new Subject();

  constructor(
    private fieldConfigService: FieldsConfigService,
    private store: Store<BaseAppState>,
  ) { }

  ngOnInit(): void {
    this.personalInfoForm = new FormGroup({
      greeting: new FormControl('', Validators.required),
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      birthDate: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.email]),
      phone: new FormControl('', Validators.required)
    });

    this.fieldConfigService.loadConfig({
      greeting: new RadioControlConfig({
        label: 'EAUTO_P2_SC3_GREETING_TITLE_Q',
        displayAs: 'row',
        options: [
          { value: '0', label: 'EAUTO_P2_SC3_GREETING_TITLE_OPTION_0' },
          { value: '1', label: 'EAUTO_P2_SC3_GREETING_TITLE_OPTION_1' }
        ],
      }),
      firstName: new TextboxControlConfig({
        label: 'EAUTO_P2_SC3_FIRST_NAME_Q',
        placeholder: 'EAUTO_P2_SC3_FIRST_NAME_PH'
      }),
      lastName: new TextboxControlConfig({
        label: 'EAUTO_P2_SC3_LAST_NAME_Q',
        placeholder: 'EAUTO_P2_SC3_LAST_NAME_PH'
      }),
      birthDate: new DateTimeControlConfig({
        label: 'EAUTO_P2_SC3_BIRTHDATE_Q',
        placeholder: 'EAUTO_P2_SC3_BIRTHDATE_PH'
      }),
      email: new TextboxControlConfig({
        controlType: 'email',
        label: 'EAUTO_P2_SC3_EMAIL_Q',
        placeholder: 'EAUTO_P2_SC3_EMAIL_PH'
      }),
      phone: new TextboxControlConfig({
        label: 'EAUTO_P2_SC3_PHONE_NUMBER_Q',
        placeholder: 'EAUTO_P2_SC3_PHONE_NUMBER_PH'
      })
    });
  }

  writeValue(value: PostalAddress) {
    value && this.personalInfoForm.setValue(value);
  }

  registerOnChange(onChange: any) {
    const sub = this.personalInfoForm.valueChanges.subscribe(onChange);
    this.onChangeSubs.push(sub);
  }

  registerOnTouched(onTouched: Function) {
    this.onTouched = onTouched;
  }

  setDisabledState(isDisabled: boolean) {
    if (isDisabled) {
      this.personalInfoForm.disable();
    } else {
      this.personalInfoForm.enable();
    }
  }

  validate(control: AbstractControl): ValidationErrors | null {
    if (control.hasValidator(Validators.required) && this.personalInfoForm.invalid) {
      return { address: true };
    }

    return null;
  }

  ngOnDestroy() {
    for (let sub of this.onChangeSubs) {
      sub.unsubscribe();
    }
  }
}
