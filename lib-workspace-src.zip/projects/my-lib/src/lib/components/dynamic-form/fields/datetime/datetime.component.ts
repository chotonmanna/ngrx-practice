import { Component, forwardRef } from '@angular/core';
import { DateTimeControlConfig } from '../../models/datetime-config.model';
import { NG_VALUE_ACCESSOR, NG_VALIDATORS } from '@angular/forms';
import { FieldsConfigService } from '../../fields-config.service';
import { BaseControlComponent } from '../base-field.component';

@Component({
  selector: 'app-field-datetime',
  templateUrl: './datetime.component.html',
  styleUrls: ['./datetime.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => DateTimeComponent)
    },
    {
      provide: NG_VALIDATORS,
      multi: true,
      useExisting: DateTimeComponent
    }
  ]
})
export class DateTimeComponent extends BaseControlComponent<DateTimeControlConfig> {
  constructor(
    protected override fieldConfigService: FieldsConfigService
  ) {
    super(fieldConfigService);
  }

}
