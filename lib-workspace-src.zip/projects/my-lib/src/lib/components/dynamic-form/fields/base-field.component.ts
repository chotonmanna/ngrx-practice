import { Component, Input, OnDestroy, OnInit } from "@angular/core";
import { AbstractControl, ControlValueAccessor, FormControl, ValidationErrors, Validator } from "@angular/forms";
import { Subscription } from "rxjs";
import { FieldsConfigService } from "../fields-config.service";

@Component({
  template: '',
})
export class BaseControlComponent<TConfig> implements OnInit, ControlValueAccessor, Validator, OnDestroy {
  @Input() formControlName!: string;
  config!: TConfig | null;

  fieldControl = new FormControl('');
  onTouched: Function = () => { };
  private onChangeSubs: Subscription[] = [];

  constructor(
    protected fieldConfigService: FieldsConfigService
  ) { }

  ngOnInit(): void {
    this.fieldConfigService.getConfig<TConfig>(this.formControlName).subscribe((resp: TConfig | null) => {
      this.config = resp;
    });
  }

  writeValue(value: any) {
    this.fieldControl.setValue(value || '');
  }

  registerOnChange(onChange: any) {
    const sub = this.fieldControl.valueChanges.subscribe(onChange);
    this.onChangeSubs.push(sub);
  }

  registerOnTouched(onTouched: Function) {
    this.onTouched = onTouched;
  }

  setDisabledState(isDisabled: boolean) {
    if (isDisabled) {
      this.fieldControl.disable();
    } else {
      this.fieldControl.enable();
    }
  }

  validate(control: AbstractControl<any, any>): ValidationErrors | null {
    //console.log(control);
    return null;
  }

  ngOnDestroy() {
    for (let sub of this.onChangeSubs) {
      sub.unsubscribe();
    }
  }

}
