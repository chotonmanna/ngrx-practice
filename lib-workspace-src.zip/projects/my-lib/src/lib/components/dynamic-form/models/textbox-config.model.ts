import { Observable } from "rxjs";

type TextBoxControlTypes = 'text' | 'email' | 'url' | 'tel' | 'range' | 'password' | 'hidden';

export class TextboxControlConfig {
  id?: string;
  label?: string;
  placeholder?: string;
  controlType?: TextBoxControlTypes;
  className?: string;
  maxLength?: number;
  autocomplete?: Array<string> | Observable<Array<string>>;

  constructor(config: TextboxControlConfig) {
    this.id = config?.id;
    this.label = config?.label || '';
    this.placeholder = config?.placeholder;
    this.className = config?.className;
    this.controlType = config?.controlType || 'text';
    this.maxLength = config?.maxLength;
    this.autocomplete = config?.autocomplete;
  }
}
