type DateTimeControlTypes = 'week'| 'time'| 'month' | 'datetime-local' | 'date';

export class DateTimeControlConfig {
  id?: string;
  label?: string;
  placeholder?: string;
  className?: string;
  minDate?: string;
  maxDate?: string;
  value?: string;
  controlType?: DateTimeControlTypes;

  constructor(config: DateTimeControlConfig) {
    this.id = config?.id;
    this.label = config?.label || '';
    this.placeholder = config?.placeholder;
    this.className = config?.className;
    this.minDate = config?.minDate;
    this.maxDate = config?.maxDate;
    this.value = config?.value;
    this.controlType = config?.controlType || 'date';
  }
}
