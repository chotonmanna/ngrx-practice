// import { UntypedFormGroup, ValidatorFn } from "@angular/forms";

// export interface IUserUpdateFieldsConfig {
//   value?: any;
//   label?: string;
//   order?: number;
//   validators?: Array<ValidatorFn | { type: ValidatorFn, msg: string }>;
//   placeholder?: string;
//   disabled?: boolean;
// }

// export class FieldControlConfig<T> {
//   id?: string;
//   label?: string;
//   placeholder?: string;

//   constructor(config: FieldControlConfig<T>) {
//     this.id = config.id;
//     this.label = config.label || '';
//     this.name = config.name;
//     this.order = config.order || 1;
//     this.validators = config.validators;
//     this.placeholder = config.placeholder || '';
//     this.disabled = config.disabled || false;
//     this.display = config.display || true;
//     this.onChange = config.onChange;
//   }
// }