export class NumberControlConfig {
  id?: string;
  label?: string;
  placeholder?: string;
  className?: string;
  min?: number;
  max?: number;
  step?: number;
  maxLength?: number;

  constructor(config: NumberControlConfig) {
    this.id = config?.id;
    this.label = config?.label || '';
    this.placeholder = config?.placeholder;
    this.className = config?.className;
    this.min = config?.min;
    this.max = config?.max;
    this.step = config?.step;
    this.maxLength = config?.maxLength;
  }
}
