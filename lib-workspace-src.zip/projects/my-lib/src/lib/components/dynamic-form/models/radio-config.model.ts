export interface IOption {
  value: string;
  label: string;
}

export class RadioControlConfig {
  label?: string;
  className?: string;
  options?: Array<IOption>;
  displayAs?: 'row' | 'column';

  constructor(config: RadioControlConfig) {
    this.label = config?.label || '';
    this.className = config?.className;
    this.options = config.options || [];
    this.displayAs = config.displayAs || 'column';
  }
}
