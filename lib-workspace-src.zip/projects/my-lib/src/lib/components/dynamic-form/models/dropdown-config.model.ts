import { Observable } from "rxjs";
import { IOption } from "./radio-config.model";

export class DropdownControlConfig {
  label?: string;
  className?: string;
  options!: Array<IOption> | Observable<Array<IOption>>;
  multiple?: boolean;
  placeholder?: string;

  constructor(config: DropdownControlConfig) {
    this.label = config?.label || '';
    this.placeholder = config?.placeholder || '';
    this.className = config?.className;
    this.options = config.options || [];
    this.multiple = config.multiple || false;
  }
}