import { Injectable } from "@angular/core";
import { TextboxControlConfig } from "./models/textbox-config.model";
import { RadioControlConfig } from "./models/radio-config.model";
import { DropdownControlConfig } from "./models/dropdown-config.model";
import { BehaviorSubject, Observable, of } from "rxjs";
import { FormGroup } from "@angular/forms";

export type IField = TextboxControlConfig | RadioControlConfig | DropdownControlConfig;
export type IFieldConfig = Record<string, IField>;
export type IFieldConfigAsync = Record<string, BehaviorSubject<IField>>;

@Injectable({
  providedIn: 'root'
})
export class FieldsConfigService {
  private fieldsConfigStorage$: IFieldConfigAsync = {};

  constructor() { }

  loadConfig(configObj: IFieldConfig) {
    for (const key in configObj) {
      if (Object.prototype.hasOwnProperty.call(configObj, key)) {
        this.fieldsConfigStorage$[key] = new BehaviorSubject<IField>(configObj[key]);
      }
    }
  }

  updateConfig<TConfig>(key: string, field: TConfig) {
    const prevValue = this.fieldsConfigStorage$[key].value;
    this.fieldsConfigStorage$[key].next({ ...prevValue, ...field });
  }

  getConfig<TConfig>(key: string): Observable<TConfig | null> {
    if (this.fieldsConfigStorage$[key]) {
      return this.fieldsConfigStorage$[key].asObservable() as Observable<TConfig>;
    } else {
      return of(null);
    }
  }

  updateControlEnableDisableStatus(form: FormGroup, field: string, status: boolean) {
    if (status) {
      form.controls[field].disabled && form.controls[field].enable();
    } else {
      form.controls[field].enabled && form.controls[field].disable();
    }
  }

}