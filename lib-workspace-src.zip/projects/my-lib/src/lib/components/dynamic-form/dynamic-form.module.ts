import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CheckboxComponent } from './fields/checkbox/checkbox.component';
import { DateTimeComponent } from './fields/datetime/datetime.component';
import { DropdownComponent } from './fields/dropdown/dropdown.component';
import { NumberComponent } from './fields/number/number.component';
import { RadioComponent } from './fields/radio/radio.component';
import { TextBoxComponent } from './fields/text/text.component';
import { FieldValidationComponent } from './validation/field-validation.component';
import { MatButtonModule } from '@angular/material/button';
import { FieldsConfigService } from './fields-config.service';
import { TranslateModule } from '@ngx-translate/core';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { AddressComponent } from './fields/address/address.component';
import { AddressFieldService } from './fields/address/address.service';
import { PersonalInfoComponent } from './fields/personalInfo/personal-info.component';

@NgModule({
  declarations: [
    RadioComponent,
    DropdownComponent,
    CheckboxComponent,
    TextBoxComponent,
    NumberComponent,
    DateTimeComponent,
    FieldValidationComponent,
    AddressComponent,
    PersonalInfoComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    TranslateModule,
    MatAutocompleteModule
  ],
  exports: [
    RadioComponent,
    DropdownComponent,
    CheckboxComponent,
    TextBoxComponent,
    NumberComponent,
    DateTimeComponent,
    AddressComponent,
    PersonalInfoComponent
  ],
  providers: []
})
export class DynamicFormModule { }
