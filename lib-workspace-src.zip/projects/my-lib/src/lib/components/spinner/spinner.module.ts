import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ElibSpinnerComponent } from './spinner.component';

@NgModule({
  declarations: [ElibSpinnerComponent],
  imports: [CommonModule],
  exports: [ElibSpinnerComponent]
})
export class ElibSpinnerModule {}
