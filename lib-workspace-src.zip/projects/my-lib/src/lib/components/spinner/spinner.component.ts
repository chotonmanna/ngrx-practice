import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpLoaderService } from '../../services/http/loader.service';

@Component({
  selector: 'elib-spinner',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.component.scss']
})
export class ElibSpinnerComponent implements OnInit {
  busy$!: Observable<boolean>;

  constructor(
    private readonly loaderService: HttpLoaderService
  ) { }

  ngOnInit(): void {
    this.busy$ = this.loaderService.getLoadingStatus();
  }
}
