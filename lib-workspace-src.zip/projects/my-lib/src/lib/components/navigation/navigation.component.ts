import { Component, Inject, OnInit, Signal, WritableSignal, computed, signal } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';
import { NAVIGATION_CONFIG, NavigationModel } from './navigation.config';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss']
})
export class NavigationComponent implements OnInit {
  listOfRoutes!: string[];
  currentUrl: WritableSignal<string> = signal('');
  progressValue: Signal<number> = computed(() => {
    return this.listOfRoutes.indexOf(this.currentUrl()) * 100 / this.listOfRoutes.length;
  });

  constructor(
    private router: Router,
    @Inject(NAVIGATION_CONFIG) public navigationList: NavigationModel[]
  ) { 
    this.listOfRoutes = this.generateRoutes();
  }

  ngOnInit(): void {
    this.router.events.pipe(filter((event): event is NavigationEnd => event instanceof NavigationEnd))
      .subscribe((e: NavigationEnd) => {
        this.currentUrl.set(e.url);
      });
  }

  isNavigationStepActive(path: string): boolean {
    return new RegExp(`^/${path}`).test(this.currentUrl());
  }

  private generateRoutes(): string[] {
    let routes: string[] = [];
    this.navigationList.forEach(n => {
      n.steps.forEach(s => {
        let path = `/${n.path}`;
        if (s) {
          path += `/${s}`;
        }
        routes.push(path);
      })
    });

    return routes;
  }
}
