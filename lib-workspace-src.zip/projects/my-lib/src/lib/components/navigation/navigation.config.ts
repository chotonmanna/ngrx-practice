import { InjectionToken } from "@angular/core";

export interface NavigationModel {
  path: string;
  steps: string[];
}

export const NAVIGATION_CONFIG = new InjectionToken<NavigationModel[]>('NAVIGATION_CONFIG');