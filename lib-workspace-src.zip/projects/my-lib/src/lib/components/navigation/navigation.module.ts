import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NavigationComponent } from './navigation.component';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  declarations: [NavigationComponent],
  imports: [CommonModule, MatProgressBarModule, TranslateModule],
  exports: [NavigationComponent]
})
export class NavigationModule { }
