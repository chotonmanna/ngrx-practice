import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { ControlContainer, FormGroupDirective } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-button-zone',
  templateUrl: './button-zone.component.html',
  styleUrls: ['./button-zone.component.scss'],
  viewProviders: [{ provide: ControlContainer, useExisting: FormGroupDirective }]
})
export class ButtonZoneComponent {
  @Input() prevUrl!: string;
  @Input() disabledNext!: () => boolean | boolean;
  @Input() disabledPrev = false;
  @Output() submit = new EventEmitter();

  constructor(
    private router: Router,
    private parentForm: FormGroupDirective
  ) { }

  onClickPrev() {
    this.router.navigateByUrl(this.prevUrl);
  }

  onClick() {
    this.submit.emit();
  }

  isDisabled(): boolean {
    if (typeof this.disabledNext === 'function') {
      return this.disabledNext();
    } if (this.parentForm.form) {
      return this.parentForm.form.invalid;
    }

    return this.disabledNext;
  }
}
