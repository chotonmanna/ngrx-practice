import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonZoneComponent } from './button-zone.component';
import { MatButtonModule } from '@angular/material/button';


@NgModule({
  declarations: [
    ButtonZoneComponent
  ],
  imports: [
    CommonModule,
    MatButtonModule
  ],
  exports: [
    ButtonZoneComponent
  ]
})
export class ButtonZoneModule { }
