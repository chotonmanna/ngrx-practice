import { ModuleWithProviders, NgModule, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppWrapperComponent } from './app-wrapper.component';
import { ElibSpinnerModule } from '../spinner';
import { NavigationModule } from '../navigation/navigation.module';
import { EffectsModule } from '@ngrx/effects';
import { ActionReducer, MetaReducer, StoreModule } from '@ngrx/store';
import { PostalAddressEffects } from '../../store/postal-address/effects';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { httpListenerInterceptor } from '../../http-listener/listener.service';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

@NgModule({
  declarations: [
    AppWrapperComponent
  ],
  imports: [
    CommonModule,
    ElibSpinnerModule,
    NavigationModule,
  ],
  providers: [
    provideHttpClient(withInterceptors([httpListenerInterceptor])),
    provideAnimationsAsync()
  ],
  exports: [AppWrapperComponent]
})
export class AppWrapperModule { 
  // static forRoot(): ModuleWithProviders<AppWrapperModule> {
  //   return {
  //     ngModule: AppWrapperModule,
      
  //   };
  // }
}
