import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CardContentsComponent } from './card-contents.component';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  declarations: [CardContentsComponent],
  imports: [CommonModule, TranslateModule],
  exports: [CardContentsComponent]
})
export class CardContentsModule { }
