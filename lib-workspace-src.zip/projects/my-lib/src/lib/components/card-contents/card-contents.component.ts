import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-card-contents',
  templateUrl: './card-contents.component.html',
  styleUrls: ['./card-contents.component.scss']
})
export class CardContentsComponent {
  @Input() title!: string | null;
}
