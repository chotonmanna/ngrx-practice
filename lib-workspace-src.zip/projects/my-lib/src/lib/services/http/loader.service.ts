import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class HttpLoaderService {
  private loadingStatus$ = new BehaviorSubject(false);

  constructor() { }

  getLoadingStatus(): Observable<boolean> {
    return this.loadingStatus$.asObservable();
  }

  setLoadingStatus(status: boolean) {
    this.loadingStatus$.next(status);
  }
}