import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class HttpClientService {
  basePath = 'https://ft.esg.api.axa.be/AXA_BE_pc_retail/axa24/v1/selling';

  constructor(
    protected http: HttpClient
  ) { }

  getRequest<T>(path: string, params = null): Observable<T> {
    return this.http.get<T>(`${this.basePath}/${path}`, {
      params: JSON.parse(JSON.stringify(params))
    });
  }

  postRequest<TReq, TResp>(path: string, params: TReq): Observable<TResp> {
    return this.http.post<TResp>(`${this.basePath}/${path}`, params);
  }

  putRequest<TReq, TResp>(path: string, params: TReq): Observable<TResp> {
    return this.http.post<TResp>(`${this.basePath}/${path}`, params);
  }
}