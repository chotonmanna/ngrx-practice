import { Injectable } from "@angular/core";

@Injectable({
  providedIn: 'root'
})
export class StoreDataService {

  getSyncData<T>(path: string, defaultValue: T | null = null): T {
    let secondPath;
    if (path.includes('.')) {
      secondPath = path.split('.')[1];
      path = path.split('.')[0];
    }

    let data = JSON.parse(sessionStorage.getItem(path) as string);

    if (secondPath) {
      data = data[secondPath];
    }

    return (data || defaultValue) as T;
  }
}