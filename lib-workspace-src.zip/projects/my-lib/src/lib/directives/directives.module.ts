import { NgModule } from '@angular/core';
import { ConnectFormDirective } from './connect-form.directive';

@NgModule({
  declarations: [ConnectFormDirective],
  exports: [ConnectFormDirective]
})
export class DirectivesModule {}
