import { Directive, Input, OnInit } from '@angular/core';
import { FormGroupDirective } from '@angular/forms';
import { Store } from '@ngrx/store';
import { debounceTime, filter, take } from 'rxjs';

import { screenAttributesActions, selectScreenAttributes } from '../store/screen-attributes';
import { ScreenAttributes } from '../models/ScreenAttributes';
import { BaseAppState } from '../models/BaseAppState';


@Directive({
  selector: '[appConnectForm]'
})
export class ConnectFormDirective implements OnInit {
  @Input() appConnectForm!: string;

  constructor(
    private formGroupDirective: FormGroupDirective,
    private store: Store<BaseAppState>
  ) { }

  ngOnInit(): void {
    this.formGroupDirective.form.valueChanges.pipe(debounceTime(600)).subscribe(screenData => {
      //console.log('get formdata');
      this.store.dispatch(screenAttributesActions.update({ screenData }));
    });

    this.store.select(selectScreenAttributes).pipe(take(1)).subscribe(screenData => {
      //console.log('set formdata');
      this.formGroupDirective.form.patchValue(screenData as ScreenAttributes);
    });
  }
}
