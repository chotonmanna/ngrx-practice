import { HttpClient, HttpErrorResponse, HttpEvent, HttpHandler, HttpHandlerFn, HttpInterceptor, HttpInterceptorFn, HttpRequest } from "@angular/common/http";
import { Injectable, inject } from "@angular/core";
import { Observable, catchError, finalize, last, tap, throwError } from "rxjs";
import { HttpLoaderService } from "../services/http/loader.service";

export const httpListenerInterceptor: HttpInterceptorFn = (req: HttpRequest<any>, next: HttpHandlerFn): Observable<HttpEvent<any>> => {
  let requestPoolCount = 0;
  const httpLoaderService = inject(HttpLoaderService);
  requestPoolCount++;
    httpLoaderService.setLoadingStatus(true);
    return next(req).pipe(
      last(),
      tap((e) => {
        
      }),
      // map((e) => {
      //   console.log('map', e);
      //   return e;
      // }),
      catchError((error: HttpErrorResponse) => {
        return throwError(error);
      }),
      finalize(() => {
        requestPoolCount--;
        if (requestPoolCount === 0) {
          httpLoaderService.setLoadingStatus(false);
        }
      })
    );
}
