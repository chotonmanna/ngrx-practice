import { createActionGroup, props } from "@ngrx/store";
import { ScreenAttributes } from "../../models/ScreenAttributes";

export const screenAttributesActions = createActionGroup({
  source: 'Screen Attributes',
  events: {
    'Update': props<{ screenData: ScreenAttributes }>(),
    'Clear': props<{ screenData: string[] }>()
  }
});