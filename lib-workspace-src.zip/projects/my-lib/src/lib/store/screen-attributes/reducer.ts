import { createReducer, on } from "@ngrx/store";
import { ScreenAttributes } from "../../models/ScreenAttributes";
import { screenAttributesActions } from "./actions";

const initialState = JSON.parse(sessionStorage.getItem('screenAttributes') as string) || {} as ScreenAttributes;

export const screenAttributesReducer = createReducer(
  initialState,
  on(screenAttributesActions.update, (state, payload) => {
    return {
      ...state,
      ...payload.screenData
    }
  }),
  on(screenAttributesActions.clear, (state, payload) => {
    const getPrevState = { ...state };
    payload.screenData.forEach(field => getPrevState[field as keyof typeof initialState] = undefined);
    return {
      ...state,
      ...getPrevState
    }
  })
);