import { createSelector, createFeatureSelector } from "@ngrx/store";
import { PostalAddress, ScreenAttributes } from "../../models/ScreenAttributes";
//import { VehicleService } from "../../../features/m1/vehicle.service";

export const selectScreenAttributes = createSelector(
  createFeatureSelector<ScreenAttributes>('screenAttributes'),
  screenAttributes => screenAttributes
);

export const selectM1Sc2Title = createSelector(
  selectScreenAttributes,
  screenData => screenData?.vehicleType === '0' ? 'Votre voiture' : 'Votre nouvelle voiture'
);

export const selectConstructionYearsOptions = (vehicleService: any) => createSelector(
  selectScreenAttributes,
  screenData => vehicleService.getConstructionYearsOptions(screenData?.firstCirculation as string)
);

export const selectVehicleFuel = createSelector(selectScreenAttributes, attrs => attrs.vehicleFuel);
export const selectVehicleGearBox = createSelector(selectScreenAttributes, attrs => attrs.vehicleGearBox);
export const selectVehiclePower = createSelector(selectScreenAttributes, attrs => attrs.vehiclePower);
export const selectNeedOmnium = createSelector(selectScreenAttributes, attrs => attrs.needOmnium === '1');
export const selectVehicleGreater18Months = createSelector(
  selectScreenAttributes,
  attrs => Number(attrs.vehicle_age_month) >= 18
);
export const selectPostalAddressScreenAttrs = createSelector(selectScreenAttributes, attrs => attrs.postalAddress as PostalAddress);