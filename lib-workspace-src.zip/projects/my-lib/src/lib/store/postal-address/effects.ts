import { Injectable, inject } from "@angular/core";
import { Actions, createEffect, ofType } from "@ngrx/effects";
import { Store } from "@ngrx/store";

import { cityProposalActions, streetProposalActions } from "./actions";
import { selectCityProposal, selectStreetProposal } from "./selectors";
import { EMPTY, catchError, exhaustMap, filter, map } from "rxjs";
import { selectPostalAddressScreenAttrs } from "../screen-attributes";
import { concatLatestFrom } from "@ngrx/operators";
import { AddressFieldService } from "../../../lib/components/dynamic-form/fields/address/address.service";
import { BaseAppState } from "../../models/BaseAppState";

@Injectable()
export class PostalAddressEffects {
  constructor(
    //private actions$: Actions,
    private addressService: AddressFieldService,
    private store: Store<BaseAppState>
  ) { }
  private actions$ = inject(Actions);
  loadCityProposal$ = createEffect(() => this.actions$.pipe(
    ofType(cityProposalActions.load),
    concatLatestFrom(() => this.store.select(selectCityProposal)),
    filter(([_, list]) => !list.length),
    exhaustMap(([action, _]) => {
      return this.addressService.geCityProposal(action.postalCode).pipe(
        map(list => cityProposalActions.update({ list })),
        catchError(() => EMPTY)
      )
    })
  ));

  // loadStreetProposal$ = createEffect(() => this.actions$.pipe(
  //   ofType(streetProposalActions.load),
  //   concatLatestFrom(() => [
  //     this.store.select(selectStreetProposal),
  //     this.store.select(selectPostalAddressScreenAttrs)
  //   ])
  //   exhaustMap(payload => {
  //     const { zip,city } = payload[2];
  //     payload[0].
  //   })
  // ))

}

