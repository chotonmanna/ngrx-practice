import { createActionGroup, emptyProps, props } from "@ngrx/store";
import { CityProposal } from "../../models/city";
import { StreetProposal } from "../../models/street";

export const cityProposalActions = createActionGroup({
  source: 'City Proposal',
  events: {
    'Load': props<{ postalCode: string }>(),
    'Update': props<{ list: CityProposal[] }>(),
    'Clear': emptyProps()
  }
});

export const streetProposalActions = createActionGroup({
  source: 'Street Proposal',
  events: {
    'Load': props<{ streetName: string }>(),
    'Update': props<{ list: StreetProposal[] }>(),
    'Clear': emptyProps()
  }
});