import { createReducer, on } from "@ngrx/store";
import { cityProposalActions, streetProposalActions } from "./actions";
import { CityProposal } from "../../models/city";
import { StreetProposal } from "../../models/street";

export interface PostalAddressData {
  cities: CityProposal[];
  streets: StreetProposal[];
}

const initialState: PostalAddressData = JSON.parse(sessionStorage.getItem('postalAddress') as string) || {
  cities: [],
  streets: []
}

export const postalAddressReducers = createReducer(
  initialState,
  on(cityProposalActions.update, (state, payload) => {
    return {
      ...state,
      cities: [...payload.list]
    }
  }),
  on(streetProposalActions.update, (state, payload) => {
    return {
      ...state,
      streets: [...payload.list]
    }
  }),
  on(cityProposalActions.clear, state => {
    return {
      ...state,
      cities: []
    }
  }),
  on(streetProposalActions.clear, state => {
    return {
      ...state,
      streets: []
    }
  })
)