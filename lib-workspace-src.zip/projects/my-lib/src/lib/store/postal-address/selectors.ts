import { createFeatureSelector, createSelector } from "@ngrx/store";
import { PostalAddressData } from "./reducer";

export const selectPostalAddress = createFeatureSelector<PostalAddressData>('postalAddressData');

export const selectCityProposal = createSelector(
  selectPostalAddress,
  (state: PostalAddressData) => state.cities.map(c => c.postal_city_name) as string[]
);

export const selectStreetProposal = createSelector(
  selectPostalAddress,
  (state: PostalAddressData) => state.streets.map(s => s.street_name) as string[]
);