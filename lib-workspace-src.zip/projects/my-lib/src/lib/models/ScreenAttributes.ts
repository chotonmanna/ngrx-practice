export interface ScreenAttributes {
  vehicleType?: string;
  carIdentification?: string;
  carVin?: string;
  firstCirculation?: string;
  carBrand?: string;
  carBrandAlt?: string;
  carModel?: string;
  carModelLabel?: string;
  vehicleConstructionYear?: string;
  vehicleFuel?: string;
  vehicleGearBox?: string;
  vehiclePower?: string;
  vehicleSerie?: string;
  vehicleInvoicePrice?: string;
  vehiclePriceOptions?: string;
  vehicleInvoiceDate?: string;
  vehicleAdas?: string;
  needOmnium?: string;
  personalInfoState?: string;
  frequentDisplacements?: string;
  occupation?: string;
  greeting?: string;
  lastName?: string;
  firstName?: string;
  birthDate?: string;
  phone?: string;
  email?: string;
  postalAddress?: PostalAddress;
  flowType?: string;
  vehicle_age_month?: string;
}

export interface PostalAddress {
  zip: string;
  city: string;
  street: string;
  number: string;
  box: string;
}
