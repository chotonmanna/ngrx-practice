export interface VehicleVersions {
  versions?: Array<VersionData>;
  flagComplete?: boolean;
}

export interface VersionData {
  eurotaxID?: string;
  brandId?: string;
  brandLabel?: string;
  modelId?: string;
  modelLabel?: string;
  constructionYear?: string;
  fuelTypeEurotaxID?: string;
  fuelTypeName?: string;
  fuelTypeMainframeID?: string;
  vehicleTypeCode?: string;
  taxHP?: string;
  bodyType?: string;
  segmentTypeInternational?: string;
  segmentTypeNational?: string;
  sportCarCat?: string;
  powerKW?: string;
  powerHP?: string;
  powerHybKW?: string;
  transmissionId?: string;
  transmissionLabel?: string;
  tractionId?: string;
  tractionLabel?: string;
  gears?: string;
  seats?: string;
  seatMax?: string;
  doors?: string;
  amountCatalogueValueWithOutOptionsExclVAT?: string;
  amountCatalogueValueWithOutOptionsExclVATStartDate?: string;
  amountCatalogueValueWithOutOptionsExclVATEndDate?: string;
  version?: string;
  typeVehicleId?: string;
  typeVehicleName?: string;
  CO2emission?: string;
  WLTPCO2emissionMin?: string;
  WLTPCO2emissionMax?: string;
  WLTPGasCO2emissionMin?: string;
  WLTPGasCO2emissionMax?: string;
  NEDCCO2emissionMin?: string;
  NEDCCO2emissionMax?: string;
  concatOutput?: string;
}
