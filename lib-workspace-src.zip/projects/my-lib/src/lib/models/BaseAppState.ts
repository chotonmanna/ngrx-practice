import { PostalAddressData } from "../store/postal-address/reducer";
import { ScreenAttributes } from "./ScreenAttributes";

export interface BaseAppState {
  screenAttributes: ScreenAttributes | null;
  postalAddressData: PostalAddressData;
}