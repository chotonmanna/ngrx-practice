export interface VehicleBrands {
  brands?: Array<BrandData>;
  flagComplete?: boolean;
}

export interface BrandData {
  brandId: string;
  brandLabel: string;
}