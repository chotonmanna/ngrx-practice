export interface VehicleModels {
  models?: Array<ModelData>;
  flagComplete?: boolean;
}

export interface ModelData {
  modelId?: string;
  modelName?: string;
}