import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NavigationModel } from 'my-lib';

export const navigationList: NavigationModel[] = [
  {
    path: 'risk',
    steps: ['', 'brand', 'details']
  },
  {
    path: 'personal-info',
    steps: ['', 'identification', 'address', 'licence', 'claims', 'occasional-drivers', 'antecedents']
  },
  {
    path: 'covers',
    steps: ['', 'options']
  },
  {
    path: 'additional-info',
    steps: ['', 'already-registered', 'dlt']
  },
  {
    path: 'contract',
    steps: ['', 'overview', 'thank-you']
  }];

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/risk'
  },
  {
    path: 'risk',
    pathMatch: 'prefix',
    loadChildren: () => import('./features/m1/m1.module').then(m => m.M1Module)
  },
  {
    path: 'personal-info',
    pathMatch: 'prefix',
    loadChildren: () => import('./features/m2/m2.module').then(m => m.M2Module)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
