import { Injectable } from "@angular/core";
import { TranslateService } from "@ngx-translate/core";
import { BrandData, VehicleBrands, ModelData, VehicleModels, VersionData, VehicleVersions, HttpClientService } from "my-lib";
import { Observable, map } from "rxjs";

export interface OptionModel {
  label: string;
  value: string
}

@Injectable({
  providedIn: 'root'
})
export class VehicleService {

  constructor(
    private httpService: HttpClientService,
    private translateService: TranslateService
  ) { }

  getListOfBrands(constructionYear: string | null): Observable<Array<BrandData>> {
    let url = 'vehicle/brands?marketType=BE&riskType=A10';
    if (constructionYear) {
      url = `${url}&constructionYear=${constructionYear}`;
    }
    return this.httpService.getRequest<VehicleBrands>(url)
      .pipe(
        map(response => response.brands || [])
      );
  }

  getListOfModels(brandId: string, constructionYear: string): Observable<Array<ModelData>> {
    return this.httpService.getRequest<VehicleModels>(`vehicle/models?brandId=${brandId}&marketType=BE&riskType=A10&constructionYear=${constructionYear}`)
      .pipe(
        map(response => response.models || [])
      );
  }

  getListOfVersions(brandId: string | undefined, modelId: string | undefined, constructionYear: string, lang = 'FR'): Observable<Array<VersionData>> {
    return this.httpService.getRequest<VehicleVersions>(`vehicle/versions?brandId=${brandId}&modelId=${modelId}&marketType=BE&riskType=A10&constructionYear=${constructionYear}&fuelType=&maxRecords=&transmission=&powerHP=&powerKW=&powerKWHyb=&language=${lang}`)
      .pipe(
        map(response => {
          if (response?.versions) {
            return response.versions.filter(v => v.amountCatalogueValueWithOutOptionsExclVAT && Number(v.amountCatalogueValueWithOutOptionsExclVAT) !== 0);
          }

          return [];
        })
      );
  }

  getConstructionYear(firstCirculation: string | null = null): string {
    if (!firstCirculation) {
      return `${(new Date()).getFullYear()}`
    }

    return firstCirculation.split('-')[0];
  }

  getConstructionYearsOptions(firstCirculation: string): OptionModel[] {
    const year = this.getConstructionYear(firstCirculation);
    return Array(10).fill('')
      .map((_, i) => ({ label: `${Number(year) - i}`, value: `${Number(year) - i}` }))
      .filter(opt => Number(opt.value) >= 2003);
  }

  getFuelOptions(vehicleVersionsList: Array<VersionData>): Array<OptionModel> {
    return vehicleVersionsList
      .map(value => value?.fuelTypeMainframeID?.replace(/^0+|0+$/g, '') || '')
      .filter((value, index, array) => array.indexOf(value) === index)
      .map(value => ({ label: this.translateService.instant(`EAUTO_P1_SC4_VEHICLE_FUEL_${value}`), value }))
  }

  private getGearBoxFromData(value: VersionData) {
    const transmissionValues = {
      '00180010': 'A',
      '00180012': 'A',
      '00180007': 'A',
      '00180001': 'M',
      '00180005': 'A',
      3: 'S',
      4: 'V'
    };
    const trans = transmissionValues[value.transmissionId as keyof typeof transmissionValues] || 'A';
    const gears = value.gears;
    return `${trans}${gears}`;
  }

  getGearBoxOptions(vehicleVersionsList: Array<VersionData>, fuel: string | undefined): Array<OptionModel> {
    return vehicleVersionsList
      .filter(value => value?.fuelTypeMainframeID?.replace(/^0+|0+$/g, '') === fuel)
      .map(value => this.getGearBoxFromData(value))
      .filter(value => value !== null)
      .filter((value, index, array) => array.indexOf(value) === index)
      .map((value: string) => {
        const type = value.substring(0, 1);
        const gears = value.substring(1, 2);
        const label = this.translateService.instant(`EAUTO_P1_SC4_VEHICLE_GEARBOX_${type}`, { gears }) as string;

        return {
          label,
          value
        };
      })
      .sort((a, b) => a.label.localeCompare(b.label));
  }

  getPowerOptions(vehicleVersionsList: Array<VersionData>, fuel?: string, gearBox?: string): Array<OptionModel> {
    const kw = this.translateService.instant('EAUTO_P1_SC4_VEHICLE_POWER_KILOWATT_SUFFIX') as string;
    const cv = this.translateService.instant('EAUTO_P1_SC4_VEHICLE_POWER_HORSEPOWER_SUFFIX') as string;

    return vehicleVersionsList
      .filter((value: VersionData) => {
        return value?.fuelTypeMainframeID?.replace(/^0+|0+$/g, '') === fuel && this.getGearBoxFromData(value) === gearBox;
      })
      .map((value: VersionData) => Number(value.powerKW))
      .filter((value, index, array) => array.indexOf(value) === index)
      .sort((a, b) => a - b)
      .map((value: number) => {
        return {
          label: `${Math.round(value * 1.35962)} ${cv} / ${value} ${kw}`,
          value: `${value}`
        };
      });
  }

  getSeriesOptions(vehicleVersionsList: Array<VersionData>, fuel?: string, gearBox?: string, power?: string): OptionModel[] {
    return vehicleVersionsList
      .filter((value: VersionData) => {
        const matchesFuel = typeof fuel !== 'undefined' && fuel !== '' ? value?.fuelTypeMainframeID?.replace(/^0+|0+$/g, '') === fuel : true;
        const matchesGearBox = typeof gearBox !== 'undefined' && gearBox !== '' ? this.getGearBoxFromData(value) === gearBox : true;
        const matchesPower = typeof power !== 'undefined' && power !== '' ? Number(value.powerKW) === Number(power) : true;

        return matchesFuel && matchesGearBox && matchesPower;
      })
      .map((value: VersionData) => {
        return {
          label: `${value.concatOutput}`,
          value: `${value.eurotaxID}`
        };
      });
  }

}
