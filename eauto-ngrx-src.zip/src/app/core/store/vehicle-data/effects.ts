import { Injectable, inject } from "@angular/core";
import { Actions, createEffect, ofType } from "@ngrx/effects";
import { concatLatestFrom } from '@ngrx/operators';
import { Store } from "@ngrx/store";
import { filter, exhaustMap, map, catchError, EMPTY } from "rxjs";
import { vehicleBrandsActions, selectVehicleBrands, vehicleModelsActions, selectVehicleModels, vehicleVersionsActions, selectVehicleVersions } from ".";
import { VehicleService } from "../../services/vehicle.service";
import { InitialAppState } from "../../models/AppState";
import { selectScreenAttributes } from "my-lib";

@Injectable()
export class VehicleDataEffects {
  constructor(
    //private actions$: Actions,
    private vehicleService: VehicleService,
    private store: Store<InitialAppState>
  ) { }

  private actions$ = inject(Actions);

  loadBrands$ = createEffect(() => this.actions$.pipe(
    ofType(vehicleBrandsActions.load),
    concatLatestFrom(() => this.store.select(selectVehicleBrands)),
    filter(([_, list]) => !list.length),
    exhaustMap(([action, _]) => {
      return this.vehicleService.getListOfBrands(action.constructionYear).pipe(
        //tap(brands => console.log('loaded brands', brands)),
        map(list => vehicleBrandsActions.update({ list })),
        catchError(err => EMPTY)
      );
    })
  ));

  loadModels$ = createEffect(() => this.actions$.pipe(
    ofType(vehicleModelsActions.load),
    concatLatestFrom(() => this.store.select(selectVehicleModels)),
    filter(([_, list]) => !list.length),
    exhaustMap(([action, _]) => {
      return this.vehicleService.getListOfModels(action.brandId, action.constructionYear).pipe(
        //tap(models => console.log('loaded models', models)),
        map(list => vehicleModelsActions.update({ list })),
        catchError(err => EMPTY)
      );
    })
  ));

  loadVersions$ = createEffect(() => this.actions$.pipe(
    ofType(vehicleVersionsActions.load),
    concatLatestFrom(() => [
      this.store.select(selectVehicleVersions),
      this.store.select(selectScreenAttributes)
    ]),
    filter(([_, list]) => !list.length),
    exhaustMap(payload => {
      const { carBrandAlt, carModel } = payload[2];
      return this.vehicleService.getListOfVersions(carBrandAlt, carModel, payload[0].constructionYear).pipe(
        //tap(list => console.log('loaded versions', list)),
        map(list => vehicleVersionsActions.update({ list }))
      )
    })
  ));
}