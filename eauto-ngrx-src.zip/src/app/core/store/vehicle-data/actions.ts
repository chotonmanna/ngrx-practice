import { createActionGroup, emptyProps, props } from "@ngrx/store";
import { BrandData, ModelData, VersionData } from "my-lib";

export const vehicleBrandsActions = createActionGroup({
  source: 'Vehicle Brands',
  events: {
    'Load': props<{ constructionYear: string | null }>(),
    'Update': props<{ list: BrandData[] }>(),
    'Clear': emptyProps()
  }
});

export const vehicleModelsActions = createActionGroup({
  source: 'Vehicle Models',
  events: {
    'Load': props<{ brandId: string, constructionYear: string }>(),
    'Update': props<{ list: ModelData[] }>(),
    'Clear': emptyProps()
  }
});

export const vehicleVersionsActions = createActionGroup({
  source: 'Vehicle Verions',
  events: {
    'Load': props<{ constructionYear: string }>(),
    'Update': props<{ list: VersionData[] }>(),
    'Clear': emptyProps()
  }
});