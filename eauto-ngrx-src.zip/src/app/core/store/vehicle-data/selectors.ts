import { createFeatureSelector, createSelector } from "@ngrx/store";
import { VehicleData } from "./reducer";
import { IOption, selectScreenAttributes, selectVehicleFuel, selectVehicleGearBox, selectVehiclePower } from "my-lib";
import { VehicleService } from "src/app/core/services/vehicle.service";

export const selectVehicleData = createFeatureSelector<VehicleData>('vehicleData');

export const selectVehicleBrands = createSelector(
  selectVehicleData,
  (state: VehicleData) => state.brands.map(b => ({ value: b.brandId, label: b.brandLabel } as IOption))
);

export const selectVehicleModels = createSelector(
  selectVehicleData,
  (state: VehicleData) => state.models.map(m => ({ value: m.modelId, label: m.modelName } as IOption))
);

export const selectVehicleVersions = createSelector(
  selectVehicleData,
  (state: VehicleData) => state.versions
);

export const selectedScreenVehicleBrand = createSelector(
  selectScreenAttributes,
  selectVehicleBrands,
  (screenAttrs, brands) => brands.find(b => b.value === screenAttrs.carBrandAlt)
);

export const selectedScreenVehicleModel = createSelector(
  selectScreenAttributes,
  selectVehicleModels,
  (screenAttrs, models) => models.find(m => m.value === screenAttrs.carModel)
);

export const selectM1Sc3Title = createSelector(
  selectedScreenVehicleBrand,
  selectedScreenVehicleModel,
  (brand, model) => `Votre ${brand?.label || ''} ${model?.label || ''}`
);

export const selectFuelsOptions = (vehicleService: VehicleService) => createSelector(
  selectVehicleVersions,
  versions => vehicleService.getFuelOptions(versions)
);

export const selectGearBoxOptions = (vehicleService: VehicleService) => createSelector(
  selectVehicleVersions,
  selectVehicleFuel,
  (versions, vehicleFuel) => versions?.length && vehicleFuel ? vehicleService.getGearBoxOptions(versions, vehicleFuel) : []
);

export const selectPowerOptions = (vehicleService: VehicleService) => createSelector(
  selectVehicleVersions,
  selectVehicleFuel,
  selectVehicleGearBox,
  (versions, vehicleFuel, gearBox) =>
    versions?.length && vehicleFuel && gearBox ? vehicleService.getPowerOptions(versions, vehicleFuel, gearBox) : []
);

export const selectSeriesOptions = (vehicleService: VehicleService) => createSelector(
  selectVehicleVersions,
  selectVehicleFuel,
  selectVehicleGearBox,
  selectVehiclePower,
  (versions, vehicleFuel, gearBox, power) =>
    versions?.length && vehicleFuel && gearBox && power ? vehicleService.getSeriesOptions(versions, vehicleFuel, gearBox, power) : []
);