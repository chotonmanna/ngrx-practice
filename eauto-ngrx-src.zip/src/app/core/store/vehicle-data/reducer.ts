import { createReducer, on } from "@ngrx/store";
import { vehicleBrandsActions, vehicleModelsActions, vehicleVersionsActions } from "./actions";
import { BrandData, ModelData, VersionData } from "my-lib";

export interface VehicleData {
  brands: BrandData[];
  models: ModelData[];
  versions: VersionData[];
}

const initialState: VehicleData = JSON.parse(sessionStorage.getItem('vehicleData') as string) || {
  brands: [],
  models: [],
  versions: []
}

export const vehicleDataReducer = createReducer(
  initialState,
  on(vehicleBrandsActions.update, (state, payload) => ({ ...state, brands: [...payload.list] })),
  on(vehicleModelsActions.update, (state, payload) => ({ ...state, models: [...payload.list] })),
  on(vehicleVersionsActions.update, (state, payload) => ({ ...state, versions: [...payload.list] })),
  on(vehicleBrandsActions.clear, state => ({ ...state, brands: [] })),
  on(vehicleModelsActions.clear, state => ({ ...state, models: [] })),
  on(vehicleVersionsActions.clear, state => ({ ...state, versions: [] }))
);