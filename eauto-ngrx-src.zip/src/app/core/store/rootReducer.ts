
import { screenAttributesReducer, postalAddressReducers } from "my-lib";
import { vehicleDataReducer } from "./vehicle-data";

export const rootReducer = {
  screenAttributes: screenAttributesReducer,
  vehicleData: vehicleDataReducer,
  postalAddressData: postalAddressReducers
};