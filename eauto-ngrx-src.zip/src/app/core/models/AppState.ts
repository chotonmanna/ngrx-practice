import { BaseAppState } from "my-lib";
import { VehicleData } from "../store/vehicle-data";


export interface InitialAppState extends BaseAppState {
  vehicleData: VehicleData;
}
