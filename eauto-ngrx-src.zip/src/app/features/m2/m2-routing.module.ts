import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { M2Sc1Component } from './sc1/sc1.component';
import { M2Sc2Component } from './sc2/sc2.component';
import { M2Sc3Component } from './sc3/sc3.component';
import { M2Sc4Component } from './sc4/sc4.component';

const routes: Routes = [
  {
    path: '',
    component: M2Sc1Component
  },
  {
    path: 'identification',
    component: M2Sc2Component
  },
  {
    path: 'address',
    component: M2Sc3Component
  },
  {
    path: 'licence',
    component: M2Sc4Component
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class M2RoutingModule { }
