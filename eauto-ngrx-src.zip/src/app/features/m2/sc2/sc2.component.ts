import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FieldsConfigService, RadioControlConfig, TextboxControlConfig } from 'my-lib';

@Component({
  selector: 'app-m2-sc2',
  templateUrl: './sc2.component.html',
  styleUrls: ['./sc2.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class M2Sc2Component implements OnInit {
  form!: FormGroup;

  constructor(
    private fieldConfigService: FieldsConfigService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      personalInfo: new FormControl('', Validators.required)
    });
  }

  onSubmit() {
    this.router.navigateByUrl('/personal-info/address');
  }
}
