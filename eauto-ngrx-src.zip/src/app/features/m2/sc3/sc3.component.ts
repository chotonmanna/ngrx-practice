import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-m2-sc3',
  templateUrl: './sc3.component.html',
  styleUrls: ['./sc3.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class M2Sc3Component implements OnInit {
  form!: FormGroup;

  constructor(
  ) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      postalAddress: new FormControl('', Validators.required)
    });
  }

  onSubmit() {

  }
}
