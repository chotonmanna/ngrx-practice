import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { M2RoutingModule } from './m2-routing.module';
import { M2Sc1Component } from './sc1/sc1.component';
import { M2Sc2Component } from './sc2/sc2.component';
import { M2Sc3Component } from './sc3/sc3.component';
import { M2Sc4Component } from './sc4/sc4.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatRadioModule } from '@angular/material/radio';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { TranslateModule } from '@ngx-translate/core';
import { CardContentsModule, ButtonZoneModule, DirectivesModule, DynamicFormModule } from 'my-lib';


@NgModule({
  declarations: [
    M2Sc1Component,
    M2Sc2Component,
    M2Sc3Component,
    M2Sc4Component
  ],
  imports: [
    CommonModule,
    M2RoutingModule,
    FormsModule,
    ReactiveFormsModule,
    CardContentsModule,
    ButtonZoneModule,
    MatRadioModule,
    TranslateModule,
    MatSelectModule,
    DirectivesModule,
    MatInputModule,
    DynamicFormModule
  ]
})
export class M2Module { }
