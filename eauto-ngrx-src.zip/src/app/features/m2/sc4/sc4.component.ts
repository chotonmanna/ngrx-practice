import { Component } from '@angular/core';

@Component({
  selector: 'app-m2-sc4',
  templateUrl: './sc4.component.html',
  styleUrls: ['./sc4.component.scss']
})
export class M2Sc4Component {

}
