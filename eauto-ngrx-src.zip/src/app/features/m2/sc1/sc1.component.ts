import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { InitialAppState } from '../../../core/models/AppState';
import { DropdownControlConfig, FieldsConfigService, NumberControlConfig, RadioControlConfig, TextboxControlConfig, screenAttributesActions } from 'my-lib';

@Component({
  selector: 'app-m2-sc1',
  templateUrl: './sc1.component.html',
  styleUrls: ['./sc1.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class M2Sc1Component implements OnInit {
  form!: FormGroup;
  shouldShowOccupation: boolean;
  shouldShowBusinessEnterprise: boolean;
  shouldShowTVA: boolean;

  constructor(
    private router: Router,
    private store: Store<InitialAppState>,
    private fieldConfigService: FieldsConfigService
  ) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      personalInfoState: new FormControl('', Validators.required),
      occupation: new FormControl('', Validators.required),
      activityCode: new FormControl('', Validators.required),
      vatDeductibilityCode: new FormControl('', Validators.required),
      tvaPercentage: new FormControl('', Validators.required),
      neonCode: new FormControl('', Validators.required)
    });

    this.fieldConfigService.loadConfig({
      personalInfoState: new RadioControlConfig({
        displayAs: 'row',
        options: [
          { value: '0', label: 'EAUTO_P2_SC1_PERSONAL_INFO_STATE_OPTION_0' },
          { value: '1', label: 'EAUTO_P2_SC1_PERSONAL_INFO_STATE_OPTION_1' },
          { value: '2', label: 'EAUTO_P2_SC1_PERSONAL_INFO_STATE_OPTION_2' }
        ],
      }),
      occupation: new DropdownControlConfig({
        label: 'Quel est le modèle ?',
        placeholder: 'Sélectionnez',
        options: [
          { value: '01', label: 'EAUTO_P2_SC2_OCCUPATION_OPTION_0' },
          { value: '32', label: 'EAUTO_P2_SC2_OCCUPATION_OPTION_1' },
          { value: '11', label: 'EAUTO_P2_SC2_OCCUPATION_OPTION_2' },
          { value: '22', label: 'EAUTO_P2_SC2_OCCUPATION_OPTION_3' },
          { value: '20', label: 'EAUTO_P2_SC2_OCCUPATION_OPTION_4' }
        ]
      }),
      activityCode: new DropdownControlConfig({
        label: 'EAUTO_P2_SC2_ACTIVITY_Q',
        placeholder: 'Sélectionnez',
        options: [
          { value: '101', label: 'EAUTO_P2_SC2_ACTIVITY_OPTION_0' },
          { value: '102', label: 'EAUTO_P2_SC2_ACTIVITY_OPTION_1' },
          { value: '103', label: 'EAUTO_P2_SC2_ACTIVITY_OPTION_2' },
          { value: '104', label: 'EAUTO_P2_SC2_ACTIVITY_OPTION_3' },
          { value: '105', label: 'EAUTO_P2_SC2_ACTIVITY_OPTION_4' },
          { value: '106', label: 'EAUTO_P2_SC2_ACTIVITY_OPTION_5' },
          { value: '107', label: 'EAUTO_P2_SC2_ACTIVITY_OPTION_6' },
          { value: '111', label: 'EAUTO_P2_SC2_ACTIVITY_OPTION_7' },
          { value: '110', label: 'EAUTO_P2_SC2_ACTIVITY_OPTION_8' },
          { value: '108', label: 'EAUTO_P2_SC2_ACTIVITY_OPTION_9' },
          { value: '109', label: 'EAUTO_P2_SC2_ACTIVITY_OPTION_10' },
          { value: '100', label: 'EAUTO_P2_SC2_ACTIVITY_OPTION_11' }
        ]
      }),
      vatDeductibilityCode: new DropdownControlConfig({
        label: 'EAUTO_P2_SC2_VAT_DEDUCTIBILITY_PERCENTAGE_Q',
        placeholder: 'Sélectionnez',
        options: [
          { value: '104', label: 'EAUTO_P2_SC2_VAT_DEDUCTIBILITY_PERCENTAGE_OPTION_0' }, 
          { value: '285', label: 'EAUTO_P2_SC2_VAT_DEDUCTIBILITY_PERCENTAGE_OPTION_1' }, 
          { value: '275', label: 'EAUTO_P2_SC2_VAT_DEDUCTIBILITY_PERCENTAGE_OPTION_2' }, 
          { value: '102', label: 'EAUTO_P2_SC2_VAT_DEDUCTIBILITY_PERCENTAGE_OPTION_3' }, 
          { value: '101', label: 'EAUTO_P2_SC2_VAT_DEDUCTIBILITY_PERCENTAGE_OPTION_4' }, 
          { value: '100', label: 'EAUTO_P2_SC2_VAT_DEDUCTIBILITY_PERCENTAGE_OPTION_5' }
        ]
      }),
      tvaPercentage: new NumberControlConfig({
        label: 'EAUTO_P2_SC2_TVAPERCENTAGE_Q',
        placeholder: 'EAUTO_P2_SC2_TVAPERCENTAGE_PH'
      }),
      neonCode: new TextboxControlConfig({
        label: 'EAUTO_P2_SC2_NEONCODE_Q',
        placeholder: 'EAUTO_P2_SC2_NEONCODE_PH'
      })
    });
  }

  onChangePersonalInfoState(): void {
    this.store.dispatch(screenAttributesActions.clear({ screenData: ['occupation'] }));
    this.updateViewState();
  }

  onChangeVatDeductibilityCode(): void {
    this.store.dispatch(screenAttributesActions.clear({ screenData: ['tvaPercentage'] }));
    this.shouldShowTVA = this.form.get('vatDeductibilityCode')?.value === '101';
    this.fieldConfigService.updateControlEnableDisableStatus(this.form, 'vatDeductibilityCode', this.shouldShowTVA);
  }

  private updateViewState(): void {
    const personalInfoState = this.form.get('personalInfoState')?.value;
    this.shouldShowOccupation = ['0'].includes(personalInfoState);
    this.shouldShowBusinessEnterprise = ['1', '2'].includes(personalInfoState);

    this.fieldConfigService.updateControlEnableDisableStatus(this.form, 'occupation', this.shouldShowOccupation);
    ['activityCode', 'vatDeductibilityCode', 'tvaPercentage', 'neonCode'].forEach(field => {
      this.fieldConfigService.updateControlEnableDisableStatus(this.form, field, this.shouldShowBusinessEnterprise);
    });
  }

  // shouldShowOccupation(): boolean {
  //   const status = this.form.get('personalInfoState')?.value === '0';
  //   this.fieldConfigService.updateControlEnableDisableStatus(this.form, 'occupation', status);
  //   return status;
  // }

  // shouldShowBusinessEnterprise(): boolean {
  //   const status = ['1', '2'].includes(this.form.get('personalInfoState')?.value);
  //   ['activityCode', 'vatDeductibilityCode', 'tvaPercentage', 'neonCode'].forEach(field => {
  //     this.fieldConfigService.updateControlEnableDisableStatus(this.form, field, status);
  //   });
  //   return status;
  // }

  // shouldShowTVA(): boolean {
  //   const status = this.form.get('vatDeductibilityCode')?.value === '101';
  //   this.fieldConfigService.updateControlEnableDisableStatus(this.form, 'vatDeductibilityCode', status);
  //   return status;
  // }

  goToNext() {
    this.router.navigateByUrl('/personal-info/identification');
  }
}
