import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { M1Sc1Component } from './sc1/sc1.component';
import { M1Sc2Component } from './sc2/sc2.component';
import { M1Sc3Component } from './sc3/sc3.component';

const routes: Routes = [
  {
    path: '',
    component: M1Sc1Component
  },
  {
    path: 'brand',
    component: M1Sc2Component
  },
  {
    path: 'details',
    component: M1Sc3Component
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class M1RoutingModule { }
