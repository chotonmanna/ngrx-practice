import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { M1RoutingModule } from './m1-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { TranslateModule } from '@ngx-translate/core';

import { M1Sc1Component } from './sc1/sc1.component';
import { M1Sc2Component } from './sc2/sc2.component';
import { M1Sc3Component } from './sc3/sc3.component';
import { ButtonZoneModule, CardContentsModule, DirectivesModule, DynamicFormModule } from 'my-lib';

@NgModule({
  declarations: [
    M1Sc1Component,
    M1Sc2Component,
    M1Sc3Component
  ],
  imports: [
    CommonModule,
    M1RoutingModule,
    CardContentsModule,
    ButtonZoneModule,
    MatRadioModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    DirectivesModule,
    MatInputModule,
    TranslateModule,
    DynamicFormModule
  ]
})
export class M1Module { }
