import { ChangeDetectionStrategy, Component, OnInit } from "@angular/core";
import { FormGroup, FormControl, Validators, ValidatorFn, AbstractControl, ValidationErrors } from "@angular/forms";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";
import { VehicleService } from "../../../core/services/vehicle.service";
import { selectNeedOmnium, selectVehicleGreater18Months, selectConstructionYearsOptions, screenAttributesActions, VersionData, ScreenAttributes, StoreDataService, getMonthDiff, numberToFixed, truncateDecimals, DropdownControlConfig, FieldsConfigService, TextboxControlConfig, DateTimeControlConfig } from "my-lib";
import { selectM1Sc3Title, selectFuelsOptions, selectGearBoxOptions, selectPowerOptions, selectSeriesOptions, vehicleVersionsActions } from "src/app/core/store/vehicle-data";
import { InitialAppState } from "src/app/core/models/AppState";

export const validateInvoicePrice = (storeDataService: StoreDataService): ValidatorFn => {
  return (control: AbstractControl) => {
    const vehicleAgeMonth = getMonthDiff(new Date(storeDataService.getSyncData<string>('screenAttributes.firstCirculation', new Date().toISOString().split('T')[0])));
    const eurotaxCatalogValue = Number(storeDataService.getSyncData<string>('screenAttributes.amountCatalogueValueWithOutOptionsExclVAT'));
    const eurotaxCatalogValueMutliplyBy07 = Number(eurotaxCatalogValue) * 0.7;
    const eurotaxCatalogValueMutliplyBy06 = Number(eurotaxCatalogValue) * 0.6;
    const eurotaxCatalogValueMultiplyBy16 = Number(eurotaxCatalogValue) * 1.6;

    let error: ValidationErrors | null = null;

    if (vehicleAgeMonth < 6 && control.value < truncateDecimals(eurotaxCatalogValueMutliplyBy07, 2)) {
      error = { EAUTO_P1_SC4_ERROR_CATALOG_VALUE: true };
    }

    if (vehicleAgeMonth >= 6 && vehicleAgeMonth <= 18 && control.value < truncateDecimals(eurotaxCatalogValueMutliplyBy06, 2)) {
      error = { EAUTO_P1_SC4_ERROR_CATALOG_VALUE: true };
    }

    if (control.value >= Number(numberToFixed(eurotaxCatalogValueMultiplyBy16))) {
      error = { EAUTO_P1_SC4_ERROR_CATALOG_VALUE: true };
    }

    return error;
  }
}

@Component({
  selector: 'app-m1-sc3',
  templateUrl: './sc3.component.html',
  styleUrls: ['./sc3.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class M1Sc3Component implements OnInit {
  form!: FormGroup;
  pageTitle$!: Observable<string>;
  selectNeedOmnium$!: Observable<boolean>;
  selectVehicleGreater18Months$!: Observable<boolean>;

  constructor(
    private router: Router,
    private store: Store<InitialAppState>,
    private vehicleService: VehicleService,
    private storeDataService: StoreDataService,
    private fieldConfigService: FieldsConfigService
  ) { }

  ngOnInit(): void {
    this.pageTitle$ = this.store.select(selectM1Sc3Title);
    this.selectNeedOmnium$ = this.store.select(selectNeedOmnium);
    this.selectVehicleGreater18Months$ = this.store.select(selectVehicleGreater18Months);

    this.loadFormFields();
  }

  private loadFormFields() {
    this.form = new FormGroup({
      vehicleConstructionYear: new FormControl('', Validators.required),
      vehicleFuel: new FormControl('', Validators.required),
      vehicleGearBox: new FormControl('', Validators.required),
      vehiclePower: new FormControl('', Validators.required),
      vehicleSerie: new FormControl('', Validators.required),
      vehicleInvoicePrice: new FormControl('', [Validators.required, validateInvoicePrice(this.storeDataService)]),
      vehicleInvoiceDate: new FormControl('', Validators.required)
    });

    this.fieldConfigService.loadConfig({
      vehicleConstructionYear: new DropdownControlConfig({
        label: 'Année de construction',
        placeholder: 'Sélectionnez',
        options: this.store.select((selectConstructionYearsOptions(this.vehicleService)))
      }),
      vehicleFuel: new DropdownControlConfig({
        label: 'Carburant',
        placeholder: 'Sélectionnez',
        options: this.store.select(selectFuelsOptions(this.vehicleService))
      }),
      vehicleGearBox: new DropdownControlConfig({
        label: 'Type de boîte de vitesse',
        placeholder: 'Sélectionnez',
        options: this.store.select(selectGearBoxOptions(this.vehicleService))
      }),
      vehiclePower: new DropdownControlConfig({
        label: 'Puissance',
        placeholder: 'Sélectionnez',
        options: this.store.select(selectPowerOptions(this.vehicleService))
      }),
      vehicleSerie: new DropdownControlConfig({
        label: 'Série',
        placeholder: 'Sélectionnez',
        options: this.store.select(selectSeriesOptions(this.vehicleService))
      }),
      vehicleInvoicePrice: new TextboxControlConfig({
        label: 'Valeur facture',
        placeholder: 'EAUTO_P1_SC4_VEHICLE_INVOICE_PRICE_PH'
      }),
      vehicleInvoiceDate: new DateTimeControlConfig({
        label: 'Date facture'
      })
    });
  }

  private loadVersions() {
    this.store.dispatch(vehicleVersionsActions.clear());
    this.store.dispatch(vehicleVersionsActions.load({ constructionYear: this.form.get('vehicleConstructionYear')?.value }));
  }

  private clearFields(fields: string[]) {
    this.store.dispatch(screenAttributesActions.clear({ screenData: fields }));
    fields.forEach(field => this.form.get(field)?.reset());
  }

  onChangeVehicleConstructionYear(): void {
    this.clearFields(['vehicleFuel', 'vehicleGearBox', 'vehiclePower', 'vehicleSerie']);
    this.loadVersions();
  }

  onChangeVehicleFuel(): void {
    this.clearFields(['vehicleGearBox', 'vehiclePower', 'vehicleSerie']);
  }

  onChangeVehicleSerie(): void {
    const vehicleData = this.storeDataService.getSyncData<Array<VersionData>>('vehicleData.versions').find(v => v.eurotaxID === this.form.get('vehicleSerie')?.value);
    this.store.dispatch(screenAttributesActions.update({
      screenData: { amountCatalogueValueWithOutOptionsExclVAT: vehicleData?.amountCatalogueValueWithOutOptionsExclVAT } as ScreenAttributes
    }));
  }

  shouldShowVehicleGearBox(): boolean {
    return !!this.form.get('vehicleFuel')?.value;
  }

  shouldShowVehiclePower(): boolean {
    return this.shouldShowVehicleGearBox() && !!this.form.get('vehicleGearBox')?.value;
  }

  shouldShowVehicleSerie(): boolean {
    return this.shouldShowVehiclePower() && !!this.form.get('vehiclePower')?.value;
  }

  shouldShowVehicleInvoicePriceAndDate(needOmnium: boolean): boolean {
    const status = needOmnium && this.shouldShowVehicleSerie() && !!this.form.get('vehicleSerie')?.value;
    this.fieldConfigService.updateControlEnableDisableStatus(this.form, 'vehicleInvoicePrice', status);
    this.fieldConfigService.updateControlEnableDisableStatus(this.form, 'vehicleInvoiceDate', status,);
    return status;
  }

  shouldShowVehicleInvoiceDate(vehicleGreater18Months: boolean) {
    this.fieldConfigService.updateControlEnableDisableStatus(this.form, 'vehicleInvoiceDate', vehicleGreater18Months,);
    return vehicleGreater18Months;
  }

  goToNext() {
    this.router.navigateByUrl('/personal-info');
  }
}
