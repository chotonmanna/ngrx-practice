import { Component, ChangeDetectionStrategy, OnInit } from "@angular/core";
import { UntypedFormGroup, UntypedFormControl, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { RadioControlConfig, FieldsConfigService, screenAttributesActions } from "my-lib";

import { InitialAppState } from "src/app/core/models/AppState";
import { vehicleBrandsActions } from "src/app/core/store/vehicle-data";


@Component({
  selector: 'app-m1-sc1',
  templateUrl: './sc1.component.html',
  styleUrls: ['./sc1.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class M1Sc1Component implements OnInit {
  form!: UntypedFormGroup;
  vehicleTypeConfig!: RadioControlConfig;

  constructor(
    private router: Router,
    private store: Store<InitialAppState>,
    private fieldConfigService: FieldsConfigService
  ) { }

  ngOnInit(): void {
    this.form = new UntypedFormGroup({
      vehicleType: new UntypedFormControl('', Validators.required)
    });

    this.fieldConfigService.loadConfig({
      vehicleType: new RadioControlConfig({
        options: [
          { value: '1', label: 'EAUTO_P1_SC1_VEHICLE_TYPE_OPTION_1' },
          { value: '0', label: 'VOITURE ACTUELLE OU DE SECONDE MAIN (a déjà été immatriculée)' }
        ],
      })
    });
  }

  goToNext() {
    if (this.form.valid) {
      this.router.navigateByUrl('/risk/brand');
    }
  }

  onChangeVehicleType() {
    this.store.dispatch(vehicleBrandsActions.clear());
    this.store.dispatch(screenAttributesActions.clear({ screenData: ['firstCirculation', 'carBrandAlt', 'carModel'] }));
  }
}
