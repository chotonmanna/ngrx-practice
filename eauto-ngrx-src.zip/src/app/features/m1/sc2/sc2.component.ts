import { Component, ChangeDetectionStrategy, OnInit } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";
import { InitialAppState } from "../../../core/models/AppState";

import { VehicleService } from "../../../core/services/vehicle.service";
import { ScreenAttributes, selectScreenAttributes, selectM1Sc2Title, screenAttributesActions, getMonthDiffWithDays, validateMinDate, DropdownControlConfig, FieldsConfigService, IOption, TextboxControlConfig, DateTimeControlConfig, isValidDate } from "my-lib";

import { selectVehicleBrands, selectVehicleModels, vehicleBrandsActions, vehicleModelsActions } from "src/app/core/store/vehicle-data";


@Component({
  selector: 'app-m1-sc2',
  templateUrl: './sc2.component.html',
  styleUrls: ['./sc2.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class M1Sc2Component implements OnInit {
  form!: FormGroup;
  listOfBrands$!: Observable<IOption[]>;
  listOfModels$!: Observable<IOption[]>;
  screenAttributes$!: Observable<ScreenAttributes>;
  pageTitle$!: Observable<string>;

  constructor(
    private router: Router,
    private store: Store<InitialAppState>,
    private vehicleService: VehicleService,
    private fieldConfigService: FieldsConfigService
  ) { }

  ngOnInit(): void {
    this.loadVehicleBrands();
    this.screenAttributes$ = this.store.select(selectScreenAttributes); // Select screen attributes
    this.pageTitle$ = this.store.select(selectM1Sc2Title); // Select page title
    this.listOfBrands$ = this.store.select(selectVehicleBrands); // Select vehicle brands
    this.listOfModels$ = this.store.select(selectVehicleModels); // Select vehicle models
    this.loadFormFields();
  }

  private loadFormFields() {
    this.form = new FormGroup({
      firstCirculation: new FormControl('', [Validators.required, validateMinDate('2003-01-01')]),
      carBrandAlt: new FormControl('', [Validators.required]),
      carModel: new FormControl('', [Validators.required])
    });

    this.fieldConfigService.loadConfig({
      firstCirculation: new DateTimeControlConfig({
        label: 'Date de 1ère mise en circulation',
        minDate: '2003-01-01'
      }),
      carBrandAlt: new DropdownControlConfig({
        label: 'Votre voiture est de la marque',
        placeholder: 'Sélectionnez',
        options: this.listOfBrands$
      }),
      carModel: new DropdownControlConfig({
        label: 'Quel est le modèle ?',
        placeholder: 'Sélectionnez',
        options: this.listOfModels$
      })
    });
  }

  shouldShowFirstCirculation(screenAttributes: ScreenAttributes): boolean {
    const status = screenAttributes?.vehicleType === '0';
    this.fieldConfigService.updateControlEnableDisableStatus(this.form, 'firstCirculation', status);
    return status;
  }

  shouldShowCarBrand(screenAttributes: ScreenAttributes): boolean {
    let status = false;
    if (!this.shouldShowFirstCirculation(screenAttributes)) {
      status = true;
    }

    if (this.form.get('firstCirculation')?.valid) {
      const firstCirculation = this.form.get('firstCirculation')?.value as string;
      status = firstCirculation?.length === 10;
    }

    this.fieldConfigService.updateControlEnableDisableStatus(this.form, 'carBrandAlt', status,);
    return status;
  }

  shouldShowCarModel(): boolean {
    const status = this.form.get('carBrandAlt')?.valid || false;
    this.fieldConfigService.updateControlEnableDisableStatus(this.form, 'carModel', status,);
    return status;
  }

  private loadVehicleBrands(constructionYear: string | null = null, clear = false) {
    if (clear) {
      this.store.dispatch(vehicleBrandsActions.clear());
    }
    this.store.dispatch(vehicleBrandsActions.load({ constructionYear }));
  }

  onChangeFirstCirculation() {
    if (this.form.get('firstCirculation')?.valid) {
      console.log(isValidDate(this.form.get('firstCirculation')?.value));
      // ['carBrandAlt', 'carModel'].forEach(field => this.form.get(field)?.reset());
      // this.store.dispatch(screenAttributesActions.clear({ screenData: ['carBrandAlt', 'carModel']}));
      // const constructionYear = this.vehicleService.getConstructionYear(this.form.get('firstCirculation')?.value);
      // this.loadVehicleBrands(constructionYear, true);
    }
  }

  onChangeCarBrand() {
    this.form.get('carModel')?.reset();
    this.store.dispatch(screenAttributesActions.clear({ screenData: ['vehicleConstructionYear', 'carModel', 'vehicleFuel', 'vehicleGearBox', 'vehiclePower', 'vehicleSerie', 'vehicleInvoicePrice', 'vehicleInvoiceDate'] }));
    this.store.dispatch(vehicleModelsActions.clear());
    this.store.dispatch(vehicleModelsActions.load({
      brandId: this.form.get('carBrandAlt')?.value,
      constructionYear: this.vehicleService.getConstructionYear(this.form.get('firstCirculation')?.value)
    }));
  }

  onChangeCarModel() {
    this.store.dispatch(screenAttributesActions.clear({ screenData: ['vehicleConstructionYear', 'vehicleFuel', 'vehicleGearBox', 'vehiclePower', 'vehicleSerie', 'vehicleInvoicePrice', 'vehicleInvoiceDate'] }));
  }

  onSubmitForm() {
    const vehicleAgeByMonthDays = getMonthDiffWithDays(this.form.get('firstCirculation')?.value);
    let screenData: ScreenAttributes = { vehicle_age_month: String(vehicleAgeByMonthDays) };

    if (vehicleAgeByMonthDays >= 96) {
      screenData = { ...screenData, needOmnium: '0', flowType: '2' };
    } else {
      screenData = { ...screenData, needOmnium: '1', flowType: '1' };
    }

    this.store.dispatch(screenAttributesActions.update({ screenData }));
    this.router.navigateByUrl('/risk/details');
  }
}
