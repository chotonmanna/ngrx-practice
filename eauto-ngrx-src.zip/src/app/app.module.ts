import { HttpClient } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { storageSync } from "@larscom/ngrx-store-storagesync";
import { EffectsModule } from "@ngrx/effects";
import { ActionReducer, MetaReducer, StoreModule } from "@ngrx/store";
import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";
import { PostalAddressEffects, AppWrapperModule, NAVIGATION_CONFIG } from "my-lib";
import { AppRoutingModule, navigationList } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { InitialAppState } from "./core/models/AppState";
import { rootReducer } from "./core/store/rootReducer";
import { VehicleDataEffects } from "./core/store/vehicle-data";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

export function httpLoaderFactory(http: HttpClient): TranslateHttpLoader {
  return new TranslateHttpLoader(http, './assets/i18n/', `.json?v=${Date.now().toString()}`);
}

export function storageSyncReducer(reducer: ActionReducer<InitialAppState>): ActionReducer<InitialAppState> {
  const metaReducer = storageSync<InitialAppState>({
    features: [
      { stateKey: 'screenAttributes' },
      { stateKey: 'vehicleData' },
      { stateKey: 'postalAddressData'}
    ],
    storage: window.sessionStorage
  });

  return metaReducer(reducer);
}

const metaReducers: MetaReducer<any>[] = [storageSyncReducer];

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    StoreModule.forRoot(rootReducer, { metaReducers }),
    EffectsModule.forRoot([VehicleDataEffects, PostalAddressEffects]),
    BrowserAnimationsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpLoaderFactory,
        deps: [HttpClient]
      },
      defaultLanguage: 'fr'
    }),
    AppWrapperModule
  ],
  providers: [
    { provide: NAVIGATION_CONFIG, useValue: navigationList }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

/**
 * screenAttributes: screenAttributesReducer
 * notification: notificationReducer
 * vehicleData: vehicleDataReducer
 */
